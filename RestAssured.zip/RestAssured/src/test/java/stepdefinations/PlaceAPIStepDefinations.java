package stepdefinations;

import io.cucumber.java.en.Given;

public class PlaceAPIStepDefinations {

	@Given("Add Place Payload")
	public void addPlace() {
		
	}
}
