package runner;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.TestNGCucumberRunner;

@CucumberOptions(features= {"src/test/java/features"},
glue="stepdefinations",
tags= {"@AddPlace"},
monochrome=true,
dryRun=false
				)
public class Runner {
	TestNGCucumberRunner testNGCucumberRunner=new TestNGCucumberRunner(this.getClass());
}
