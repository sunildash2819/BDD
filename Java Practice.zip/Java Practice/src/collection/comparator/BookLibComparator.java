package collection.comparator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

class BookLib {
	int id;
	String name;
	int quantity;

	public BookLib(int id, String name, int quantity) {
		this.id = id;
		this.name = name;
		this.quantity = quantity;
	}
}

class NameComparator implements Comparator<BookLib> {

	@Override
	public int compare(BookLib o1, BookLib o2) {
		return o1.name.compareTo(o2.name);
	}
}

class IdComparator implements Comparator<BookLib> {

	@Override
	public int compare(BookLib o1, BookLib o2) {
		if (o1.id > o2.id)
			return 1;
		else if (o1.id < o2.id)
			return -1;
		else
			return 0;
	}
}

class QuantityComparator implements Comparator<BookLib> {

	@Override
	public int compare(BookLib o1, BookLib o2) {
		if (o1.quantity > o2.quantity)
			return 1;
		else if (o1.quantity < o2.quantity)
			return -1;
		else
			return 0;
	}
}

public class BookLibComparator {

	public static void main(String[] args) {
		ArrayList<BookLib> al = new ArrayList<>();

		al.add(new BookLib(235, "Let us C", 500));
		al.add(new BookLib(699, "Data Communications & Networking", 345));
		al.add(new BookLib(123, "Operating System", 211));
		al.add(new BookLib(654, "Automation", 157));
		al.add(new BookLib(980, "JAVA Basics", 655));

		System.out.println("Before sorting : ");
		for (BookLib b : al) {
			System.out.println(b.id + " " + b.name + " " + b.quantity);
		}
		System.out.println();

		Collections.sort(al, new NameComparator());

		System.out.println("After sorting by Name : ");
		for (BookLib b : al) {
			System.out.println(b.id + " " + b.name + " " + b.quantity);
		}
		System.out.println();
		
		Collections.sort(al, new IdComparator());

		System.out.println("After sorting by Id : ");
		for (BookLib b : al) {
			System.out.println(b.id + " " + b.name + " " + b.quantity);
		}
		System.out.println();
		
		Collections.sort(al, new QuantityComparator());

		System.out.println("After sorting by Quantity : ");
		for (BookLib b : al) {
			System.out.println(b.id + " " + b.name + " " + b.quantity);
		}
	}
}
