package collection.queue;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Iterator;

public class ArrayDequeImpl {
	
	public static void arrayDequeOperations() {
		Deque<Integer> dq = new ArrayDeque<>();
		dq.add(4);
		dq.addLast(12);
		dq.addFirst(3);
		dq.offer(10);
		dq.offerLast(5);
		dq.offerFirst(1);
		dq.push(8);
		System.out.println(dq);
		
		System.out.println(dq.pop());
		System.out.println(dq);
		System.out.println(dq.peek());
		System.out.println(dq);
		System.out.println(dq.poll());
		System.out.println(dq);
		System.out.println(dq.remove());
		System.out.println(dq);
		
		Iterator<Integer> i = dq.descendingIterator();
		while(i.hasNext()) {
			System.out.println(i.next());
		}
		for(int e : dq) {
			System.out.println(e);
		}
	}

	public static void main(String[] args) {
		arrayDequeOperations();
	}

}
