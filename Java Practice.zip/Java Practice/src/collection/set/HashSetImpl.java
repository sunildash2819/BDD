package collection.set;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;

class Book implements Comparable<Book>{
	int id;
	String name;
	double price;
	public Book(int id,String name, double price) {
		this.id=id;
		this.name=name;
		this.price=price;
	}
	@Override
	public int compareTo(Book b) {
		if(price>b.price)
			return 1;
		else if(price<b.price)
			return -1;
		else
			return 0;
	}
}

public class HashSetImpl {

	public static void main(String[] args) {
		Book b1 = new Book(1, "ABC", 20);
		Book b2 = new Book(2, "DEF", 30);
		Book b3 = new Book(3, "GHI", 40);
		Book b4 = new Book(4, "JKL", 50);
		
		HashSet<Book> hs = new HashSet<>();
		hs.add(b3);
		hs.add(b2);
		hs.add(b1);
		hs.add(b4);
		
		for(Book b : hs) {
			System.out.println(b.id+" "+b.name+" "+b.price);
		}
		
		ArrayList<Book> al = new ArrayList<>(hs);
		Collections.sort(al);
		
		for(Book b : al) {
			System.out.println(b.id+" "+b.name+" "+b.price);
		}
		/*HashSet<Integer> hs = new HashSet<>();
		hs.add(1);
		hs.add(4);
		hs.add(2);
		hs.add(3);
		System.out.println(hs);
		Iterator<Integer> i = hs.iterator();
		while(i.hasNext()) {
			System.out.println(i.next());
		}
		ArrayList<Integer> al = new ArrayList<>(hs);
		Collections.sort(al);
		System.out.println(al);*/
	}

}
