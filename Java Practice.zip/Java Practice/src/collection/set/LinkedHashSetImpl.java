package collection.set;

import java.util.LinkedHashSet;

class Book1{
	int id;
	String name;
	double price;
	public Book1(int id,String name, double price) {
		this.id=id;
		this.name=name;
		this.price=price;
	}
}

public class LinkedHashSetImpl {

	public static void main(String[] args) {
		Book b1 = new Book(1, "ABC", 20);
		Book b2 = new Book(2, "DEF", 30);
		Book b3 = new Book(3, "GHI", 40);
		Book b4 = new Book(4, "JKL", 50);
		
		LinkedHashSet<Book> hs = new LinkedHashSet<>();
		hs.add(b1);
		hs.add(b3);
		hs.add(b4);
		hs.add(b2);
		
		/*for(Book b : hs) {
			System.out.println(b.id+" "+b.name+" "+b.price);
		}*/
		
		hs.forEach(b->{System.out.println(b.id+" "+b.name+" "+b.price);});
		
	}

}
