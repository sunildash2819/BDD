package collection.set;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.TreeSet;

public class TreeSetImpl {

	public static void descendingItr() {
		TreeSet<Integer> ts = new TreeSet<>();
		ts.add(3);
		ts.add(7);
		ts.add(1);
		ts.add(6);
		ts.add(5);
		System.out.println(ts);
		Iterator<Integer> i = ts.descendingIterator();
		while(i.hasNext()) {
			System.out.print(i.next()+" ");
		}
	}

	public static void ceilingFloorImpl() {
		TreeSet<Integer> ts = new TreeSet<>();
		ts.add(3);
		ts.add(7);
		ts.add(1);
		ts.add(6);
		ts.add(5);
		System.out.println(ts);
		System.out.println(ts.ceiling(4));
		System.out.println(ts.floor(10));
		System.out.println(ts.higher(5));
		System.out.println(ts.lower(2));
	}

	public static void accessFirstAndLastElements() {
		TreeSet<Integer> ts = new TreeSet<>();
		for(int i=1;i<=10;i++) {
			ts.add(new Random().nextInt(100));
		}
		System.out.println(ts);
		System.out.println(ts.first());
		System.out.println(ts.last());
		System.out.println(ts.pollFirst());
		System.out.println(ts.pollLast());
		System.out.println(ts);
		System.out.println(ts.descendingSet());
	}
	
	public static void treesetWithCollections() {
		TreeSet<Integer> ts = new TreeSet<>();
		ts.add(3);
		ts.add(7);
		ts.add(1);
		ts.add(6);
		ts.add(5);
		System.out.println("TreeSet : "+ts);
		
		ArrayList<Integer> al = new ArrayList<>();
		al.add(2);
		al.add(10);
		al.add(9);
		al.add(4);
		System.out.println("ArrayList : "+al);
		
		ts.addAll(al);
		System.out.println("TreeSet : "+ts);
		ts.removeAll(al);
		System.out.println("TreeSet : "+ts);
	}
	
	public static void headSetTailSetImpl() {
		TreeSet<Integer> ts = new TreeSet<>();
		for(int i=1;i<=10;i++) {
			ts.add(i);
		}
		System.out.println(ts);
		System.out.println(ts.headSet(9));
		System.out.println(ts.headSet(9, true));
		System.out.println(ts.tailSet(4));
		System.out.println(ts.tailSet(4, false));
	}
	
	public static void subsetImpl() {
		TreeSet<Integer> ts = new TreeSet<>();
		for(int i=1;i<=10;i++) {
			ts.add(i);
		}
		System.out.println(ts);
		System.out.println(ts.subSet(2, 8));
		System.out.println(ts.subSet(2, true, 8, true));
	}
	
	
	public static void main(String[] args) {
		descendingItr();
		ceilingFloorImpl();
		accessFirstAndLastElements();
		treesetWithCollections();
		headSetTailSetImpl();
		subsetImpl();
	}

}
