package collection.set;

import java.util.ArrayList;
import java.util.Collections;
import java.util.TreeSet;

class BookLibrary implements Comparable<BookLibrary> {

	int id;
	String name;
	double price;

	public BookLibrary(int id, String name, double price) {
		this.id = id;
		this.name = name;
		this.price = price;
	}

	//String comparison using comparable
	/*@Override
	public int compareTo(BookLibrary b) {
		return this.name.compareTo(b.name);
	}*/
	
	@Override
	public int compareTo(BookLibrary b) {
		if(price<b.price)
			return 1;
		else if(price>b.price)
			return -1;
		else
			return 0;
	}
}

public class TreeSetClassTypeImpl {

	public static void main(String[] args) {
		BookLibrary b1 = new BookLibrary(120, "Let us C", 250);
		BookLibrary b2 = new BookLibrary(23, "Operating System", 58);
		BookLibrary b3 = new BookLibrary(322, "Data Communications & Networking", 400);
		BookLibrary b4 = new BookLibrary(122, "Theory of automation", 145);

		TreeSet<BookLibrary> ts = new TreeSet<>();
		ts.add(b1);
		ts.add(b2);
		ts.add(b3);
		ts.add(b4);
		
		ArrayList<BookLibrary> al = new ArrayList<>(ts);
		Collections.sort(al);

		for (BookLibrary b : al) {
			System.out.println(b.id + " " + b.name + " " + b.price);
		}
	}

}
