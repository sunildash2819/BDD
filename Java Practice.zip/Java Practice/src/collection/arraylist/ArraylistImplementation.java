package collection.arraylist;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Random;

public class ArraylistImplementation {

	public static void arrayListGetSet() {
		ArrayList<Integer> list = new ArrayList<>();
		for(int i=1;i<=5;i++)
			list.add(i);
		System.out.println(list);
		System.out.println("Element at 1st position : "+list.get(0));
		list.set(0, 7);
		System.out.println("Element at 1st position : "+list.get(0));
		}
	
	public static void arrayListIterate() {
		List<Integer> arrayList = new ArrayList<Integer>();
		for(int i=1;i<=5;i++)
			arrayList.add(i);
		
		System.out.println(arrayList);
		System.out.println("Iterating array list using iterator");
		Iterator<Integer> itr = arrayList.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		System.out.println("Iterating array list using for-each loop");
		for(int i:arrayList) {
			System.out.println(i);
		}
		
		System.out.println("Iterating array list using list iterator(reverse order)");
		ListIterator<Integer> listItr = arrayList.listIterator(arrayList.size());
		while(listItr.hasPrevious()) {
			System.out.println(listItr.previousIndex()+" "+listItr.previous());
		}
		
		System.out.println("Iterating array list using foreach method");
		arrayList.forEach(a->{System.out.println(a);});
		
		System.out.println("Iterating array list using forEachRemaining method");
		Iterator<Integer> itr2 = arrayList.iterator();
 		itr2.forEachRemaining(a->{System.out.println(a);});
 		
 		ListIterator<Integer> lItr = arrayList.listIterator();
 		lItr.forEachRemaining(a->{System.out.println(a);});
	}
	
	public static void arrayListAdd() {

		List<Integer> l1 = new ArrayList<>();
		l1.add(1);
		l1.add(2);
		l1.add(3);
		System.out.println("list : "+l1);
		l1.add(2, 4);
		System.out.println("list : "+l1);
		
		List<Integer> l2 = new ArrayList<>();
		l2.add(5);
		l2.add(6);
		l2.add(6);
		l2.add(5);
		l1.addAll(l2);
		System.out.println("list : "+l1);
		
		List<Integer> l3 = new ArrayList<>();
		l3.add(8);
		l3.add(9);
		l3.add(6);
		System.out.println("List l3 : "+l3);
		l2.addAll(l3);
		System.out.println("List l2 : "+l2);
		l1.addAll(l2);
		System.out.println("List l1 : "+l1);
	}

	public static void arrayListRemove() {
		ArrayList<Integer> list = new ArrayList<>();
		for(int i=1;i<=10;i++)
			list.add(i);
		System.out.println(list);
		list.remove(3);
		System.out.println(list);
		list.remove(0);
		System.out.println(list);
		
		ArrayList<Integer> list2 = new ArrayList<>();
		list2.add(11);
		list2.add(12);
		list2.add(13);
		list.addAll(list2);
		
		System.out.println(list);
		list.removeAll(list2);
		System.out.println(list);
		list.clear();
		System.out.println(list);
	}
	
	public static void arrayListRetainAll() {
		ArrayList<Integer> al = new ArrayList<>();
		for(int i=1;i<=5;i++) {
			al.add(i);
		}
		ArrayList<Integer> al2 = new ArrayList<>();
		al2.add(7);
		al2.add(8);
		al.addAll(al2);
		al.retainAll(al2);
		Iterator<Integer> itr = al.iterator();
		while(itr.hasNext()) {
			System.out.print(itr.next()+" ");
		}
		Object al3 = al.clone();
		System.out.println(al3);
		System.out.println(al.containsAll(al2));
		System.out.println(al.toString());
		String s = al.toString();
		System.out.println(s);
	}
	
	public static void collectionsClassImplementation() {
		ArrayList<Integer> al = new ArrayList<>();
		for(int i=1;i<=10;i++) {
			al.add(new Random().nextInt(100));
		}
		System.out.println(al);
		Collections.sort(al);
		System.out.println(al);
		Collections.addAll(al, 10);
		System.out.println(al);
		
		/*Collections.swap(al, 2, 7);
		System.out.println(al);*/
		
		/*Collections.shuffle(al);
		System.out.println(al);
		*/
		/*Collections.sort(al, Collections.reverseOrder());
		System.out.println(al);*/
		
		/*Collections.reverse(al);
		System.out.println(al);*/
		
		//Left rotation
		/*Collections.rotate(al, al.size()-2);
		System.out.println(al);
		
		//Right rotation
		Collections.rotate(al, 2);
		System.out.println(al)*/;
		
		/*ArrayList<Integer> al2 = new ArrayList<>(10);
		for(int i=1;i<=10;i++) {
			al2.add(new Random().nextInt(100));
		}
		System.out.println(al.size());
		System.out.println(al2.size());
		Collections.copy(al2, al);
		System.out.println(al2);*/
		
		/*Collections.fill(al, 10);
		System.out.println(al);*/
		
	}
	
	public static void ConvertArrayListToArrays() {
		List<Integer> al = new ArrayList<>();
		for(int i=1;i<=10;i++)
			al.add(i);
		System.out.println("ArrayList : "+al);
		System.out.println("Converting ArrayList to Array");
		Integer[] arr = al.toArray(new Integer[al.size()]);
		for(Integer i : arr)
			System.out.print(i+" ");
		
		System.out.println("\nConverting Array to ArrayList");
		List<Integer> al2 = Arrays.asList(arr);
		System.out.println(al2);
	}
	
	public static void main(String[] args) {
		arrayListIterate();
		arrayListGetSet();
		arrayListAdd();
		arrayListRemove();
		arrayListRetainAll();
		collectionsClassImplementation();
		ConvertArrayListToArrays();
	}

}
