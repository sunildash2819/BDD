package collection.arraylist;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

class Student implements Comparable<Student>{
	int roll;
	String name;
	int age;
	public Student(int roll,String name,int age) {
		this.roll=roll;
		this.name=name;
		this.age=age;
	}
	@Override
	public int compareTo(Student s) {
		if(roll>s.roll)
			return 1;
		else if(roll<s.roll)
			return -1;
		else
			return 0;
	}
}

public class ArrayListClassType {

	public static void main(String[] args) {
		Student s1 = new Student(1, "ABC", 10);
		Student s2 = new Student(2, "DEF", 20);
		Student s3 = new Student(3, "GHI", 30);
		Student s4 = new Student(4, "JKL", 40);
		
		ArrayList<Student> al = new ArrayList<>();
		al.add(s2);
		al.add(s4);
		al.add(s3);
		al.add(s1);
		
		Collections.sort(al);
		
		for(Student s:al) {
			System.out.println(s.age+" "+s.name+" "+s.roll);
		}

		/*Iterator<Student> itr = al.iterator();
		while(itr.hasNext()) {
			Student s = itr.next();
			System.out.println(s.age+" "+s.name+" "+s.roll);
		}
		
	*/
	}

}
