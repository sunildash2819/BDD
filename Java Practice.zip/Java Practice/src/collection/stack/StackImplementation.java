package collection.stack;

import java.util.LinkedList;
import java.util.Random;
import java.util.Stack;

public class StackImplementation {
	
	public static void isEmptyImpl() {
		Stack<Integer> s = new Stack<>();
		System.out.println("Stack is empty? "+s.empty());
		s.push(1);
		System.out.println(s);
		System.out.println("Stack is empty? "+s.empty());
	}
	
	public static void pushPodImpl() {
		Stack<Integer> s = new Stack<>();
		System.out.println("Stack : "+s);
		for(int i=1;i<=5;i++) {
			int n=new Random().nextInt(50);
			System.out.print("Push -> "+n);
			s.push(n);
			System.out.println("\nStack : "+s);
		}
		System.out.println();
		while(!(s.empty())) {
			System.out.println("Pop -> "+s.pop());
			System.out.println("Stack : "+s);
		}
		
	}

	public static void searchImpl() {
		Stack<Integer> s = new Stack<>();
		s.push(3);
		s.push(45);
		s.push(23);
		s.push(67);
		s.push(12);
		s.push(2);
		System.out.println(s);
		int location = s.search(23);  
		System.out.println(location);
	}
	
	public static void linkedlistStackImpl() {
		LinkedList<Integer> ll = new LinkedList<>();
		System.out.println("Stack : "+ll);
		for(int i=1;i<=5;i++) {
			int n=new Random().nextInt(50);
			System.out.print("Push -> "+n);
			//LinkedList push() method will add the elements at the beginning of the list.
			ll.push(n);
			System.out.println("\nStack : "+ll);
		}
		System.out.println();
		while(!(ll.isEmpty())) {
			//LinkedList pop() method will remove the elements from the beginning of the list.
			System.out.println("Pop -> "+ll.pop());
			System.out.println("Stack : "+ll);
		}
	}
	
	public static void main(String[] args) {
		isEmptyImpl();
		pushPodImpl();
		searchImpl();
		linkedlistStackImpl();
	}

}
