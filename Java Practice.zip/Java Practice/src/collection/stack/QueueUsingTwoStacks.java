package collection.stack;

import java.util.Stack;

class Queue{
	Stack<Integer> stack1;
	Stack<Integer> stack2;
}

public class QueueUsingTwoStacks {
	
	public static void main(String[] args) {
		Queue q = new Queue();
		q.stack1 = new Stack<>();
		q.stack2 = new Stack<>();
		enQueue(q,17);
		enQueue(q,34);
		enQueue(q,19);
		enQueue(q,23);
		
		deQueue(q);
		deQueue(q);
		deQueue(q);
		deQueue(q);
	}

	public static void enQueue(Queue q, int ele) {
		push(q.stack1,ele);
	}

	public static void push(Stack<Integer> stack, int ele) {
		stack.push(ele);
	}
	
	public static void deQueue(Queue q) {
		int x;
		if(q.stack1.isEmpty() && q.stack2.isEmpty()) {
			System.out.println("Queue is empty");
		}
		else {
			if(q.stack2.isEmpty()) {
				while(!(q.stack1.isEmpty())) {
					x = pop(q.stack1);
					push(q.stack2, x);
				}
			}
			x=pop(q.stack2);
			System.out.print(x+" ");
		}
	}

	public static int pop(Stack<Integer> stack) {
		if(stack.isEmpty()) {
			System.out.println("Stack Underflow");
		}
		return stack.pop();
	}
}
