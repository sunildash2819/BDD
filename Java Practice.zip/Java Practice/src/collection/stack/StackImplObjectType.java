package collection.stack;

import java.util.Random;
import java.util.Stack;

class Student {
	String name;
	int age;
	double avg;
	public Student(String name, int age, double avg) {
		this.name=name;
		this.age=age;
		this.avg=avg;
	}
}


public class StackImplObjectType {

	public static void main(String[] args) {
		Stack<Student> s = new Stack<>();
		for(int i=65;i<70;i++) {
			String name=String.valueOf((char)i);
			s.push(new Student(name, new Random().nextInt(20), (double)(new Random().nextInt(100))));
		}
		
		while(!(s.empty())) {
			System.out.println(s.peek().name+" "+s.peek().age+s.peek().avg);
			s.pop();
		}
	}
}
