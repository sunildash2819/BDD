package collection.stack;

import java.util.Stack;

public class BalancedBrackets {

	public static void main(String[] args) {
		String s="()[] {}";
		char[] ch = s.toCharArray();
		Stack<Character> st = new Stack<>();
		boolean isBBalancedBrackets=true;
		for(int i=0;i<ch.length;i++) {
			if(ch[i]=='[' || ch[i]=='{' || ch[i]=='(')
				st.push(ch[i]);
			else if(ch[i]==']' || ch[i]=='}' || ch[i]==')'){
				char x=ch[i];
				char y = st.pop();
				if(checkBalancedBracket(x, y))
					continue;
				else {
					System.out.println("False");
					isBBalancedBrackets=false;
					break;
				}
			}
		}
		if(isBBalancedBrackets)
			System.out.println("True");
	}

	public static boolean checkBalancedBracket(char x, char y) {
		boolean flag=false;
		switch (x) {
		case ']':
			if(y=='[')
				flag=true;
			break;
		case '}':
			if(y=='{')
				flag=true;
			break;
		case ')':
			if(y=='(')
				flag=true;
			break;
		}
		return flag;
	}

}
