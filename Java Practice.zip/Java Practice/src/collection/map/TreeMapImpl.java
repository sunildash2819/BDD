package collection.map;

import java.util.Iterator;
import java.util.NavigableMap;
import java.util.TreeMap;

public class TreeMapImpl {
	
	public static void navigableMap() {
		NavigableMap<Integer, String> map = new TreeMap<>();
		map.put(1, "ABC");
		map.put(6, "DEF");
		map.put(3, "GHI");
		map.put(2, "JKL");
		System.out.println(map);
		System.out.println("descendingMap: "+map.descendingMap()); 
		System.out.println("headMap: "+map.headMap(6));
		System.out.println("headMap: "+map.headMap(2,true));
		System.out.println("tailMap: "+map.tailMap(2));
		System.out.println("tailMap: "+map.tailMap(2,true));  
		System.out.println("subMap: "+map.subMap(1, true, 6, true));  
	}

	public static void treeMapEntryImpl() {
		TreeMap<Integer, String> tm = new TreeMap<>();
		tm.put(7, "School");
		tm.put(1, "Student");
		tm.put(5, "Book");
		tm.put(2, "Library");
		System.out.println(tm);
		System.out.println("Ceiling entry : "+tm.ceilingEntry(5));
		System.out.println("Ceiling key : "+tm.ceilingKey(3));
		System.out.println("Floor entry : "+tm.floorEntry(6));
		System.out.println("Floor key : "+tm.floorKey(3));
		
		System.out.println("First entry : "+tm.firstEntry());
		System.out.println("First entry : "+tm.lastEntry());
		
		System.out.println("Higher entry : "+tm.higherEntry(5));
		System.out.println("higher key : "+tm.higherKey(3));
		System.out.println("lower entry : "+tm.lowerEntry(5));
		System.out.println("lower key : "+tm.lowerKey(3));
		
		System.out.println("poll first entry : "+tm.pollFirstEntry());
		System.out.println("poll last entry : "+tm.pollLastEntry());
		System.out.println(tm);
	}
	
	public static void descendingKeySetImpl() {
		TreeMap<Integer, String> tm = new TreeMap<>();
		tm.put(7, "School");
		tm.put(1, "Student");
		tm.put(5, "Book");
		tm.put(2, "Library");
		
		Iterator<Integer> itr = tm.descendingKeySet().iterator();
		while(itr.hasNext()) {
			int key=itr.next();
			System.out.println(key+" "+tm.get(key));
		}
		Iterator<Integer> itr2 = tm.descendingKeySet().descendingIterator();
		while(itr2.hasNext()) {
			int key=itr2.next();
			System.out.println(key+" "+tm.get(key));
		}
	}
	
	public static void main(String[] args) {
//		navigableMap();
//		treeMapEntryImpl();
		descendingKeySetImpl();
	}

}
