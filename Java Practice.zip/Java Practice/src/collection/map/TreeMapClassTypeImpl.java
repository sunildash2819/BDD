package collection.map;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

class BookLib implements Comparable<BookLib>{
	int id;
	String name;
	int quantity;

	public BookLib(int id, String name, int quantity) {
		this.id = id;
		this.name = name;
		this.quantity = quantity;
	}

	@Override
	public int compareTo(BookLib b) {
		if(quantity<b.quantity)
			return 1;
		else if(quantity>b.quantity)
			return -1;
		else
			return 0;
	}
}

public class TreeMapClassTypeImpl {

	public static void main(String[] args) {
		BookLib b1=new BookLib(101,"Let us C",80);    
		BookLib b2=new BookLib(102,"Data Communications & Networking",40);    
		BookLib b3=new BookLib(103,"Operating System",60);  
		BookLib b4=new BookLib(104,"Automation",20);
		
		TreeMap<BookLib, Integer> tm = new TreeMap<>();
		tm.put(b3, 3);
		tm.put(b1, 1);
		tm.put(b4, 4);
		tm.put(b2, 2);
		 
		//Each iterator will have key element of the map
		
		/*Iterator<BookLib> itr = tm.keySet().iterator();
		while(itr.hasNext()) {
			BookLib b = itr.next();
			int value = tm.get(b);
			System.out.println(value+" : "+b.id+" "+b.name+" "+b.quantity);
		}*/
		
		//Each iterator will have key-value entry of the map. So must use Entry interface
		
		/*Iterator<Entry<BookLib, Integer>> itr = tm.entrySet().iterator();
		while(itr.hasNext()) {
			Map.Entry<BookLib, Integer> e = itr.next();
			BookLib b = e.getKey();
			int value = e.getValue();
			System.out.println(value+" : "+b.id+" "+b.name+" "+b.quantity);
		}*/
		
		/*for(Map.Entry<BookLib, Integer> entry : tm.entrySet()) {
			BookLib b = entry.getKey();
			System.out.println(entry.getValue()+" : "+b.id+" "+b.name+" "+b.quantity);
		}*/
		
	}

}
