package collection.map;

import java.util.LinkedHashMap;
import java.util.Map;

class Book implements Comparable<Book>{
	int id;
	String name, author, publisher;
	int quantity;

	public Book(int id, String name, String author, String publisher, int quantity) {
		this.id = id;
		this.name = name;
		this.author = author;
		this.publisher = publisher;
		this.quantity = quantity;
	}

	@Override
	public int compareTo(Book b) {
		return name.compareTo(b.name);
	}
}

public class LinkedHashMapImpl {
	
	public static void linkedHashMapOperations() {
		Book b1=new Book(101,"Let us C","Yashwant Kanetkar","BPB",80);    
	    Book b2=new Book(102,"Data Communications & Networking","Forouzan","Mc Graw Hill",40);    
	    Book b3=new Book(103,"Operating System","Galvin","Wiley",60);  
		
	    Map<Book,Integer> map=new LinkedHashMap<Book,Integer>();  
	    map.put(b2,2);  
	    map.put(b1,1);  
	    map.put(b3,3);
	    
	    for(Map.Entry<Book,Integer> entry:map.entrySet()){    
	        Book key=entry.getKey();  
	        int v=entry.getValue();  
	        System.out.println(key.id+" "+key.name+" "+key.author+" "+key.publisher+" "+key.quantity+"\n");
	        System.out.println(v+" Details:");  
	    }
	    
		LinkedHashMap<Integer, String> lm = new LinkedHashMap<>();
		lm.put(3, "ABC");
		lm.put(2, "DEF");
		lm.put(4, "GHI");
		lm.put(1, "JKL");
		lm.put(5, "JKL");
		
		for(Map.Entry<Integer, String> entry : lm.entrySet()) {
			System.out.println(entry.getKey()+" "+entry.getValue());
		}
	}

	public static void main(String[] args) {
		linkedHashMapOperations();
	}

}
