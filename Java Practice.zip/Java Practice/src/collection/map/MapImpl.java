package collection.map;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class MapImpl {

	public static void keySetImpl() {
		Map<Integer, String> m = new HashMap<Integer, String>();
		m.put(1, "ABC");
		m.put(2, "DEF");
		m.put(3, "GHI");
		m.put(4, "JKL");
		m.put(5, "MNO");

		System.out.println(m);

		Set<Integer> set = m.keySet();
		Iterator<Integer> itr = set.iterator();
		while (itr.hasNext()) {
			Object key = itr.next();
			System.out.println(key + " " + m.get(key));
		}
	}
	
	public static void entrySetImpl() {
		Map<Object, Object> m = new HashMap<Object, Object>();
		m.put(1, "ABC");
		m.put(2, "DEF");
		m.put(3, "GHI");
		m.put(4, "JKL");
		m.put(5, "MNO");
		System.out.println(m);
		
		for(Map.Entry<Object, Object> entry : m.entrySet()) {
			System.out.println(entry.getKey()+" "+entry.getValue());
		}
	}

	public static void comparingByKeyImpl() {
		Map<Integer, String> m = new HashMap<Integer, String>();
		m.put(3, "GHI");
		m.put(1, "ABC");
		m.put(2, "DEF");
		m.put(5, "MNO");
		m.put(4, "JKL");
		
		System.out.println(m);
		
		//Ascending order
		m.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(System.out::println);
		System.out.println();
		//Descending order
		m.entrySet().stream().sorted(Map.Entry.comparingByKey(Comparator.reverseOrder())).forEach(System.out::println);
	}

	public static void  comparingByValueImpl() {
		Map<Integer, String> m = new HashMap<Integer, String>();
		m.put(1, "ABC");
		m.put(2, "DEF");
		m.put(3, "GHI");
		m.put(4, "JKL");
		m.put(5, "MNO");
		
		System.out.println(m);
		
		m.entrySet().stream().sorted(Map.Entry.comparingByValue()).forEach(System.out::println);
		System.out.println();
		m.entrySet().stream().sorted(Map.Entry.comparingByValue(Comparator.reverseOrder())).forEach(System.out::println);
	}
	
	public static void mapOperations() {
		Map<Object, Object> map = new HashMap<>();
		map.put(1, "ABC");
		map.put(2, "DEF");
		map.put(3, "GHI");
		map.put(4, "JKL");
		map.put(4, null);
		map.put(5, 6);
		map.put(5, null);
		map.put(null, null);
		map.putIfAbsent(5, "new value");
		map.putIfAbsent(null, "new value");
		map.putIfAbsent(6, "6");
		System.out.println(map);
		
		map.put(1, "ABC");
		map.put(2, "DEF");
		map.put(3, "GHI");
		map.put(4, "JKL");
		map.put(5, "MNO");
		System.out.println(map);
		/*map.remove(1);
		System.out.println(map);
		map.remove(5, "MNO");
		map.remove(3, "value");
		System.out.println(map);
		System.out.println(map.containsKey(6));
		System.out.println(map.containsValue("value"));
		
		System.out.println(map.get(2));
		System.out.println(map.getOrDefault(6, null));*/
		
		map.replace(4, "value");
		map.replace(8, "value");
		System.out.println(map);
		map.replace(3, "GHI", "new value");
		System.out.println(map);
		System.out.println(map.values());
		Collection<Object> arr = map.values();
		System.out.println(arr);
		
		String[] values = map.values().toArray(new String[0]);
		System.out.println(Arrays.toString(values));
		
		
		HashSet<Integer> hs = new HashSet<>();
		hs.add(1);
		hs.add(2);
		hs.add(3);
		hs.add(4);
		hs.add(5);
		Integer[] a = hs.toArray(new Integer[hs.size()]);
		System.out.println(Arrays.toString(a));
		
		Object[] keys =  map.keySet().toArray();
		System.out.println(Arrays.toString(keys));
		
		Set<Object> set = map.keySet();
		Object[] k = set.toArray();
		System.out.println(Arrays.toString(k));
		
		Object[] v = map.values().toArray();
		System.out.println(Arrays.toString(v));
		
		Object[] v2 = map.entrySet().toArray();
		System.out.println(Arrays.toString(v2));
		
	}

	public static void main(String[] args) {
		keySetImpl();
		entrySetImpl();
		comparingByKeyImpl();
		comparingByValueImpl();
		mapOperations();
	}

}
