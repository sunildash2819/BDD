package collection.map;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

class School {
	int id;
	String name;
	int numOfStudents;
	
	public School(int id,String name, int numOfStudents) {
		this.id=id;
		this.name=name;
		this.numOfStudents=numOfStudents;
	}

}


public class HashMapImpl {

	public static void main(String[] args) {
		School s1 = new School(1, "VEMS", 200);
		School s2 = new School(2, "DAV", 500);
		School s3 = new School(3, "Mothers", 450);
		School s4 = new School(4, "KV", 600);
		
		HashMap<Integer, School> hs = new HashMap<>();
		hs.put(101, s3);
		hs.put(102, s2);
		hs.put(103, s4);
		hs.put(104, s1);
		
		for(int key:hs.keySet()) {
			School s = hs.get(key);
			System.out.println(s.id+" "+s.name+" "+s.numOfStudents);
		}
		
		for(Map.Entry<Integer, School> entry : hs.entrySet()) {
			School s = entry.getValue();
			System.out.println(s.id+" "+s.name+" "+s.numOfStudents);
		}
		
//		hashTable();
	}

	public static void hashTable() {
		Hashtable<Integer, String> ht = new Hashtable<>();
		ht.put(101, "ABC");
		ht.put(103, "DEF");
		ht.put(104, "GHI");
		ht.put(102, "JKL");
		
		System.out.println(ht);
	}
}
