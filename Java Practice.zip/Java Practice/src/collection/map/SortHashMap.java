/**
 * To sort HashMap, there are 2 ways:
 * 1)sort by keys
 * 2)sort by values
 * 
 * To sort by keys there are 2 ways: sort using TreeMap and sort using LinkedHashMap.
 * To sort by values, sort using LinkedHashMap.
 * 
 * For sort using TreeMap, refer TreeMapClassTypeImpl.java class file.
 * For sort using LinkedHashMap, below is the example.
 */

package collection.map;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Map.Entry;

class StudentLib {
	int id;
	String name;
	int quantity;

	public StudentLib(int id, String name, int quantity) {
		this.id = id;
		this.name = name;
		this.quantity = quantity;
	}
}

class QuantityComparator implements Comparator<Entry<Integer, StudentLib>>{

	@Override
	public int compare(Entry<Integer, StudentLib> o1, Entry<Integer, StudentLib> o2) {
		if (o1.getValue().quantity > o2.getValue().quantity)
			return 1;
		else if (o1.getValue().quantity < o2.getValue().quantity)
			return -1;
		else
			return 0;
	}
}

class NameComparator implements Comparator<Entry<Integer, StudentLib>>{

	@Override
	public int compare(Entry<Integer, StudentLib> o1, Entry<Integer, StudentLib> o2) {
		return o1.getValue().name.compareTo(o2.getValue().name);
	}
}

public class SortHashMap {

	public static void sortByLinkedHashMapForObjectType() {

		HashMap<Integer, StudentLib> hm = new HashMap<>();
		hm.put(3, new StudentLib(101, "Let us C", 234));
		hm.put(1, new StudentLib(102, "Data Communications & Networking", 656));
		hm.put(4, new StudentLib(103, "Operating System", 121));
		hm.put(2, new StudentLib(104, "Automation", 989));

		System.out.println("Before sorting : ");
		for (Entry<Integer, StudentLib> e : hm.entrySet()) {
			StudentLib b = e.getValue();
			System.out.println(e.getKey() + " : " + b.id + " " + b.name + " " + b.quantity);
		}

		LinkedList<Entry<Integer, StudentLib>> list = new LinkedList<>(hm.entrySet());

//		Collections.sort(list, new QuantityComparator());
		Collections.sort(list, new NameComparator());

		LinkedHashMap<Integer, StudentLib> lm = new LinkedHashMap<>();
		for (Entry<Integer, StudentLib> e : list) {
			lm.put(e.getKey(), e.getValue());
		}

		System.out.println("After sorting : ");
		for (Entry<Integer, StudentLib> e : lm.entrySet()) {
			StudentLib b = e.getValue();
			System.out.println(e.getKey() + " : " + b.id + " " + b.name + " " + b.quantity);
		}
	}

	public static void sortByLinkedHashMap() {
		// Create HashMap and enter values
		HashMap<Integer, Integer> hm = new HashMap<>();
		hm.put(1, 234);
		hm.put(2, 656);
		hm.put(3, 121);
		hm.put(4, 223);
		hm.put(5, 989);
		System.out.println("Before sorting : ");
		System.out.println(hm);

		// Convert HashMap to set and convert set to list(LinkedList)
		LinkedList<Entry<Integer, Integer>> list = new LinkedList<>(hm.entrySet());

		// Sort list using Collections.sort(list, comparator) method
		// Below implementation is for sort by values. To sort by keys, use getKey()
		// method.
		Collections.sort(list, new Comparator<Entry<Integer, Integer>>() {
			public int compare(Entry<Integer, Integer> o1, Entry<Integer, Integer> o2) {
				return o1.getValue().compareTo(o2.getValue());
			}
		});

		// Create a LinkedHashMap and insert values into it from the list
		LinkedHashMap<Integer, Integer> lm = new LinkedHashMap<>();
		for (Map.Entry<Integer, Integer> e : list) {
			lm.put(e.getKey(), e.getValue());
		}
		System.out.println("After sorting : ");
		System.out.println(lm);
	}

	public static void main(String[] args) {
//		sortByLinkedHashMap();
		sortByLinkedHashMapForObjectType();
	}
}
