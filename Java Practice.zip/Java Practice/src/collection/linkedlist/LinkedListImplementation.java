package collection.linkedlist;

import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Random;

public class LinkedListImplementation {
	
	public static void linkedlistAdd() {
		LinkedList<Integer> ll = new LinkedList<>();
		for(int i=1;i<=5;i++)
			ll.add(i);
		System.out.println(ll);
		ll.addFirst(7);
		System.out.println("ll.addFirst : "+ll);
		ll.addLast(8);
		System.out.println("ll.addLast : "+ll);
		ll.offer(10);
		System.out.println("ll.offer : "+ll);
		ll.offerFirst(20);
		System.out.println("ll.offerFirst : "+ll);
		ll.offerLast(30);
		System.out.println("ll.offerLast : "+ll);
	}

	public static void linkedlistRemove() {
		LinkedList<Integer> ll = new LinkedList<>();
		for(int i=1;i<=10;i++)
			ll.add(i);
		System.out.println(ll);
		ll.remove();
		System.out.println("ll.remove : "+ll);
		ll.removeFirst();
		System.out.println("ll.removeFirst : "+ll);
		ll.removeLast();
		System.out.println("ll.removeLast : "+ll);
		ll.add(15);
		ll.addFirst(15);
		ll.addLast(15);
		ll.add(5, 15);
		System.out.println("New List : "+ll);
		ll.removeFirstOccurrence(15);
		System.out.println("ll.removeFirstOccurrence(15) : "+ll);
		ll.removeLastOccurrence(15);
		System.out.println("ll.removeLastOccurrence(15) : "+ll);
		ll.remove(4);
		System.out.println("ll.remove(index(4)) : "+ll);
	}
	
	public static void linkedlistRetrieveElements() {
		LinkedList<Integer> ll = new LinkedList<>();
		for(int i=21;i<=35;i++)
			ll.add(i);
		System.out.println(ll);
		
		System.out.println("ll.element() : "+ll.element());
		System.out.println("ll.getFirst() : "+ll.getFirst());
		System.out.println("ll.getLast() : "+ll.getLast());
		
		System.out.println("ll.peek() : "+ll.peek());
		System.out.println("ll.peekFirst() : "+ll.peekFirst());
		System.out.println("ll.peekLast() : "+ll.peekLast());
		System.out.println("List : "+ll);
		
		System.out.println("ll.poll() : "+ll.poll());
		System.out.println("List : "+ll);
		System.out.println("ll.pollFirst() : "+ll.pollFirst());
		System.out.println("List : "+ll);
		System.out.println("ll.pollLast() : "+ll.pollLast());
		System.out.println("List : "+ll);
	}
	
	public static void linkedlistItr() {
		LinkedList<Integer> ll = new LinkedList<>();
		for(int i=21;i<=35;i++)
			ll.add(i);
		System.out.println(ll);
		
		Iterator<Integer> itr  = ll.descendingIterator();
		while(itr.hasNext()) {
			System.out.print(itr.next()+" ");
		}
		
		ListIterator<Integer> lItr = ll.listIterator();
		while(lItr.hasPrevious()) {
			System.out.print(lItr.previous()+" ");
		}
	}
	
	public static void collectionsClassImplement() {
		LinkedList<Integer> ll = new LinkedList<>();
		for(int i=21;i<=35;i++)
			ll.add(new Random().nextInt(50));
		System.out.println(ll);
		
//		Collections.sort(ll);
//		System.out.println(ll);
		
//		Collections.sort(ll,Collections.reverseOrder());
//		System.out.println(ll);
		
		Collections.reverse(ll);
		System.out.println(ll);
		System.out.println(Collections.max(ll));
	}
	
	public static void main(String[] args) {
		linkedlistAdd();
		linkedlistRemove();
		linkedlistRetrieveElements();
		linkedlistItr();
		collectionsClassImplement();
	}

}
