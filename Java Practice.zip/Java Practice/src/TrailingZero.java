
public class TrailingZero {

	public static void main(String[] args) {
		int n=100;
		long fact=1,rem;
		int ctr=0;
		/*for(int i = 1;i<=n;i++) {
			fact*=i;
		}
		System.out.println(fact);
		while(fact!=0) {
			rem=fact%10;
			if(rem==0)
				ctr++;
			fact=fact/10;
		}*/
		
		while(n%5==0) {
			ctr++;
			n=n/5;
		}
		System.out.println("Number of trailing zeros : "+ctr);
	}

}
