package sortingalgorithms;

public class SelectionSort {

	public void sort(int arr[], int n) {
		int i,j,min,temp;
		for(i=0;i<n-1;i++) {
			min=i;
			for(j=i+1;j<n;j++) {
				if(arr[j]<arr[min]) {
					min=j;
				}
			}
			temp=arr[i];
			arr[i]=arr[min];
			arr[min]=temp;
		}
		System.out.println("After sorting:");
		for(i=0;i<arr.length;i++) {
			System.out.print(arr[i]+" ");
		}
	}
	public static void main(String[] args) {
		SelectionSort obj =new SelectionSort();
		int arr[]= {32,5,65,31,1,45,6};
		obj.sort(arr, arr.length);
	}

}
