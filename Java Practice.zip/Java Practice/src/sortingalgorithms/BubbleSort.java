package sortingalgorithms;

public class BubbleSort {

	public void sort(int arr[]) {
		int n=arr.length;
		int i,j,temp;
		for(i=0;i<n-1;i++) {
			for(j=0;j<n-i-1;j++) {
				if(arr[j]>arr[j+1]) {
					temp=arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=temp;
				}
			}
		}
		System.out.println("After sorting:");
		for(i=0;i<arr.length;i++) {
			System.out.print(arr[i]+" ");
		}
	}
	public static void main(String[] args) {
		BubbleSort obj =new BubbleSort();
		int arr[]= {32,5,65,31,1,45,6};
		obj.sort(arr);
	}

}
