package sortingalgorithms;

public class InsertionSort {

	public void sort(int arr[]) {
		int n=arr.length;
		int i,j,k;
		for(i=1;i<n;i++) {
			k=arr[i];
			j=i-1;
			while(j>=0 && arr[j]>k) {
				arr[j+1]=arr[j];
				j=j-1;
			}
			arr[j+1]=k;
		}
		System.out.println("After sorting:");
		for(i=0;i<arr.length;i++) {
			System.out.print(arr[i]+" ");
		}
	}
	public static void main(String[] args) {
		InsertionSort obj =new InsertionSort();
		int arr[]= {32,5,65,31,1,45,6};
		obj.sort(arr);
	}

}
