package sortingalgorithms;

public class QuickSort {

	public void sort(int arr[], int low, int high) {
		if(low<high) {
			int pivot=partition(arr,low,high);
			sort(arr,low,pivot-1);
			sort(arr,pivot+1,high);
		}
	}
	public int partition(int arr[], int low, int high) {
		int i=low-1, pivot=arr[high],j,temp;
		for(j=low;j<high;j++) {
			if(arr[j]<=pivot) {
				i++;
				temp=arr[i];
				arr[i]=arr[j];
				arr[j]=temp;
			}
		}
		temp=arr[i+1];
		arr[i+1]=arr[high];
		arr[high]=temp;
		
		return i+1;
	}
	public void print(int arr[]) {
		System.out.println("After sorting:");
		for(int i=0;i<arr.length;i++) {
			System.out.print(arr[i]+" ");
		}
	}
	public static void main(String[] args) {
		QuickSort obj =new QuickSort();
		int arr[]= {32,5,65,31,1,45,6};
		obj.sort(arr,0,arr.length-1);
		obj.print(arr);
	}

}
