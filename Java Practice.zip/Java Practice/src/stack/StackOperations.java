package stack;

public class StackOperations {

	public static int top=-1;
	public static int[] arr = new int[10];
	public static void push(int n) {
		if(top>=10) {
			System.out.println("Stack overflow");
		}
		else {
			System.out.println(n);
			top++;
			arr[top]=n;
		}
	}
	public static void pop() {
		if(top<0) {
			System.out.println("Stack is empty");
		}
		else {
			int x=arr[top];
			top--;
			System.out.println(x);
		}
	}
	public static void main(String[] args) {
		System.out.println("Pushing elements to stack");
		for(int i=1;i<=5;i++) {
			push(i*10);
		}
		System.out.println("Popping elements from stack");
		for(int i=1;i<=5;i++) {
			pop();
		}
	}

}
