package stack;

import java.util.Scanner;

public class FindMaxElement {

	static int[] a;
	static int size,top=-1;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n,ele;
		System.out.println("Enter size of the stack");
		size=sc.nextInt();
		a = new int[size];
		do {
			System.out.println("Enter your choice. 1-Push 2-Pop 3-Print maximum element 4-Print Elements 5-Exit");
			n=sc.nextInt();
			switch(n) {
			case 1:
				System.out.println("Enter element to Push");
				ele=sc.nextInt();
				push(ele);
				break;
			case 2:
				pop();
				break;
			case 3:
				printMaxElement();
				break;
			case 4:
				printElements();
				break;
			}
		}while(!(n>4));
		System.out.println("------------------EXIT-----------------");
		sc.close();
	}

	public static void printElements() {
		if(top<0) {
			System.out.println("Stack underflow - No element is present in the stack");
		}
		else {
			int t=top;
			System.out.println("Stack Elements:");
			while(!(t<0)) {
				System.out.println(a[t]);
				t--;
			}
		}
	}

	public static void printMaxElement() {
		int max=Integer.MIN_VALUE;
		if(top<0) {
			System.out.println("Stack underflow - No element is present in the stack");
		}
		else {
			for(int i =top;i>=0;i--) {
				if(a[i]>max)
					max=a[i];
			}
			System.out.println("Maximum element in the stack : "+max);
		}
	}

	public static void pop() {
		if(top<0) {
			System.out.println("Stack underflow");
		}
		else{
			int x=a[top];
			System.out.println(x+" popped");
			top--;
		}
	}

	public static void push(int ele) {
		if(top>=size) {
			System.out.println("Stack overflow");
		}
		else {
			top++;
			a[top]=ele;
			System.out.println("Element Pushed");
		}
	}

}
