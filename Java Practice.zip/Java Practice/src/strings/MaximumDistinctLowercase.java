package strings;

public class MaximumDistinctLowercase {

	public static void main(String[] args) {
		String s = "zACaAbbaazzC";
		int l=s.length();
		int i,j,ctr=0,maxCtr=0;
		for(i=0;i<l-1;i++) {
			if(s.charAt(i)>='A' && s.charAt(i)<='Z') {
				j=i+1;
				ctr=0;
				while(!(s.charAt(j)>='A' && s.charAt(j)<='Z')) {
					if(s.charAt(j)!=s.charAt(j-1))
						ctr++;
					i=j;
					j++;
				}
				maxCtr=ctr;
			}
		}
		System.out.println("Maximum distinct lowercase count : "+maxCtr);
	}

}
