package strings;

public class TotalVowelsAndConsonants {

	public static void main(String[] args) {
		String s = "First Java Program";
		int vCtr=0, cCtr=0;
		System.out.println(s);
		s=s.toUpperCase();
		for(int i=0;i<s.length();i++) {
			if(s.charAt(i)=='A' || s.charAt(i)=='E' || s.charAt(i)=='I' || s.charAt(i)=='O' || s.charAt(i)=='U')
				vCtr++;
			else if(s.charAt(i)>='A' && s.charAt(i)<='Z')
				cCtr++;
		}
		System.out.println("No. of Vowels : "+vCtr);
		System.out.println("No. of Consonants : "+cCtr);
	}

}
