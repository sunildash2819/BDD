package strings;

public class CheckStringRotationOfAnother {

	public static void main(String[] args) {
		/*String s1="ABCDE";
		String copy=s1.concat(s1);
		String s2 = "DEABA";
		boolean flag=false;
		for(int i=0;i<s2.length();i++) {
			String s=copy.substring(i, s2.length()+i);
			if(s.equals(s2)) {
				flag=true;
				break;
			}
		}
		if(flag==true)
			System.out.println(s2+" is a rotation of "+s1);
		else
			System.out.println(s2+" is not a rotation of "+s1);*/
		String str1 = "abcde", str2 = "deabc";    
        
        if(str1.length() != str2.length()){    
            System.out.println("Second string is not a rotation of first string");    
        }    
        else {    
            str1 = str1.concat(str1);    
             //Check whether str2 is present in str1    
            if(str1.indexOf(str2) != -1)    
                System.out.println("Second string is a rotation of first string");    
            else    
                System.out.println("Second string is not a rotation of first string");    
        }
	}

}
