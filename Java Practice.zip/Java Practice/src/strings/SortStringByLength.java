package strings;

public class SortStringByLength {

	public static void main(String[] args) {
		String []arr = {"GeeksforGeeks", "I", "from", "am"};
		sort(arr);
	}

	public static void sort(String[] s) {
		int len=s.length;
		int i,j;
		String temp;
		for(i=1;i<len;i++) {
			temp=s[i];
			j=i-1;
			while(j>=0 && temp.length()<s[j].length()) {
				s[j+1]=s[j];
				j--;
			}
			s[j+1]=temp;
		}
		for(i=0;i<s.length;i++) {
			System.out.print(s[i]+" ");
		}
	}
}
