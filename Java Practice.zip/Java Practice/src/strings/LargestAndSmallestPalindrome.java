package strings;

public class LargestAndSmallestPalindrome {

	public static void main(String[] args) {
		String s = "Wow you own kayak abcdcba";
		String[] words = s.toLowerCase().split(" ");
		int max = 0, min = s.length(),len;
		String maxWord = "", minWord = "";
		for (int i = 0; i < words.length; i++) {
			if (isPalindrome(words[i])) {
				len = words[i].length();
				if (max < len) {
					max = len;
					maxWord = words[i];
				} if (min > len) {
					min = len;
					minWord = words[i];
				}
			}
		}
		System.out.println("Largest palindrome : " + maxWord);
		System.out.println("Smallest palindrome : " + minWord);
	}

	private static boolean isPalindrome(String string) {
		int len = string.length();
		boolean isPalindrome = true;
		for (int i = 0; i < len / 2; i++) {
			if (string.charAt(i) != string.charAt(len - 1 - i)) {
				isPalindrome = false;
				break;
			}
		}
		return isPalindrome;
	}

}
