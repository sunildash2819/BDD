package strings;

import java.util.Arrays;

public class PrintAllAnagrams {

	public static void main(String[] args) {
		String[] s = {"cat", "dog", "tac", "god", "act", "gdo"};
		int l=s.length;
		for(int i=0;i<l-1;i++) {
			if(s[i]!="0") {
				for(int j=i+1;j<l;j++) {
					boolean isAnagram=checkAnagram(s[i], s[j]);
					if(isAnagram) {
						System.out.println(s[i]+" and "+s[j]+" are anagram");
						s[j]="0";
					}
				}
			}
		}
	}
	public static boolean checkAnagram(String s1, String s2) {
		if(s1.length()!=s2.length()) {
			return false;
		}
		char[] ch1 = s1.toCharArray();
		char[] ch2 = s2.toCharArray();
		Arrays.sort(ch1);
		Arrays.sort(ch2);
		if(Arrays.equals(ch1, ch2))
			return true;
		else
			return false;
	}

}
