package strings;

public class CommonCharacters {

	public static void main(String[] args) {
		String str[] = { "geeksforgeeks", "gemkstones", "acknowledges", "aguelikes" };
		boolean flag;
		for(char ch='a';ch<='z';ch++) {
			String s = String.valueOf(ch);
			flag=true;
			for(int i=0;i<str.length;i++) {
				if(str[i].contains(s)) {
					continue;
				}
				else {
					flag=false;
					break;
				}
			}
			if(flag==true)
				System.out.print(s+" ");
		}
	}

}
