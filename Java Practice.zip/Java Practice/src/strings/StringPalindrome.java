package strings;

public class StringPalindrome {

	public static void main(String[] args) {
		String s="ABCBA";
		/*String copyString = s;
		char[] ch = copyString.toCharArray();
		int l = ch.length;
		char temp;
		for(int i=0,j=l-1;i<j;i++,j--) {
			temp=ch[i];
			ch[i]=ch[j];
			ch[j]=temp;
		}
		copyString=String.valueOf(ch);
		if(s.equals(copyString))
			System.out.println("Palindrome");
		else
			System.out.println("Not Palindrome");*/
		int len=s.length();
		boolean flag=true;
		for(int i=0;i<len/2;i++)
		{
			if(s.charAt(i)!=s.charAt(len-1-i)) {
				flag=false;
				break;
			}
		}
		if(flag==true)
			System.out.println("Palindrome");
		else
			System.out.println("Not Palindrome");
	}

}
