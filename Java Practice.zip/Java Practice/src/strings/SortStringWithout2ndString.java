package strings;

public class SortStringWithout2ndString {

	public static void main(String[] args) {
		String arr[] = {"geeks", "quiz", "geeks", "for"};
		sort(arr);
	}
	
	public static void sort(String[] s) {
		int len = s.length;
		int[] index = new int[len];
		int i,j,min;
		for(i=0;i<len;i++) {
			index[i]=i;
		}
		for(i=0;i<len-1;i++) {
			min=i;
			for(j=i+1;j<len;j++) {
				if(s[index[min]].compareTo(s[index[j]])>0) {
					min=j;
				}
			}
			if(min!=i) {
				int temp=index[min];
				index[min]=index[i];
				index[i]=temp;
			}
		}
		for(i=0;i<s.length;i++) {
			System.out.print(s[index[i]]+" ");
		}
	}

}
