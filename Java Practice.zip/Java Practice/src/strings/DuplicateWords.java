package strings;

public class DuplicateWords {

	public static void main(String[] args) {
		String s = "Big black bug bit a big black dog on his big black nose";
		String[] words = s.split(" ");
		int ctr;
		for(int i=0;i<words.length;i++) {
			ctr=1;
			for(int j=i+1;j<words.length;j++) {
				if(words[i].equals(words[j])) {
					ctr++;
					words[j]="0";
				}
			}
			if(ctr>1 && words[i]!="0")
				System.out.println(words[i]);
		}
	}

}
