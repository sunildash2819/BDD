package strings;

public class MaxMinOccurenceInString {

	public static void main(String[] args) {
		String s="grass is greener on the other side";
		int freq[] = new int[s.length()];
		char maxChar=s.charAt(0),minChar=s.charAt(0);
		int i,j,min,max;
		char[] ch = s.toCharArray();
		for(i=0;i<s.length();i++) {
			freq[i]=1;
			for(j=i+1;j<s.length();j++) {
				if(ch[i]==ch[j] && ch[i]!=' ' && ch[i]!='0') {
					freq[i]++;
					ch[j]='0';
				}
			}
		}
		min=freq[0];
		max=freq[0];
		for(i=0;i<freq.length;i++) {
			if(min>freq[i] && freq[i]!='0') {
				min=freq[i];
				minChar=ch[i];
			}
			if(max<freq[i] && freq[i]!='0') {
				max=freq[i];
				maxChar=ch[i];
			}
		}
		System.out.println("Minimum occurring character: " + minChar);    
	    System.out.println("Maximum occurring character: " + maxChar);  
	}

}
