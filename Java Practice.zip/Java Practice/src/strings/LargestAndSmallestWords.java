package strings;

public class LargestAndSmallestWords {

	public static void main(String[] args) {
		String s = "Hardships often prepare ordinary people for an extraordinary destiny";
		String[] words = s.split(" ");
		int max=0,min=s.length();
		String maxWord="",minWord="";
		int len;
		for(int i=0;i<words.length;i++) {
			len=words[i].length();
			if(max<len) {
				max=len;
				maxWord=words[i];
			}
			else if(min>len) {
				min=len;
				minWord=words[i];
			}	
		}
		System.out.println("Largest word : "+maxWord);
		System.out.println("Smallest word : "+minWord);
	}

}
