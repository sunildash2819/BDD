package strings;

import java.util.Arrays;

public class Anagram {

	public static void main(String[] args) {
		String s1 = "Brag";
		String s2 = "Grab";
		if(s1.length()!=s2.length()) {
			System.out.println("Two strings are not anagram");
			System.exit(0);
		}
		else {
			s1=s1.toLowerCase();
			s2=s2.toLowerCase();
			char[] ch1 = s1.toCharArray();
			char[] ch2 = s2.toCharArray();
			
			Arrays.sort(ch1);
			Arrays.sort(ch2);
			s1=String.valueOf(ch1);
			s2=String.valueOf(ch2);
			
			if(s1.equals(s2))
				System.out.println("Two strings are anagram");
			else
				System.out.println("Two strings are not anagram");
		}
	}

}
