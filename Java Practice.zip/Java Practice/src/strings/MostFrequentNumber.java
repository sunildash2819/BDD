package strings;

public class MostFrequentNumber {

	public static void main(String[] args) {
		int x = 1225533; 
		int maxCount=1,result=0;
	   for(int d=0;d<=9;d++) {
		   int count=countOccurences(x,d);
		   if(count>=maxCount) {
			   maxCount=count;
			   result=d;
		   }
	   }
	   System.out.println("Max count is "+result+" with count "+maxCount);
	}

	private static int countOccurences(int x, int d) {
		int count=0;
		while(x!=0) {
			int digit=x%10;
			if(digit==d)
				count++;
			x=x/10;
		}
		return count;
	}

}
