package strings;

public class StringsRotationOfAnother {

	public static void main(String[] args) {
		String s1="ABACD", s2="CDABA";
		if(s1.length()!=s2.length())
			System.out.println("Not rotation");
		else {
			String str=s1;
			boolean flag=false;
			for(int i=1;i<=s1.length();i++) {
				str=str.substring(1)+str.substring(0, 1);
				if(str.equals(s2)) {
					System.out.println("Rotation");
					flag=true;
					break;
				}
			}
			if(flag==false)
				System.out.println("Not rotation");
		}
	}
	

}
