package strings;

public class TotalCharactersInString {

	public static void main(String[] args) {
		String s="Hello World";
		int ctr=0;
		for(int i=0;i<s.length();i++) {
			if(s.charAt(i)!=' ')
				ctr++;
		}
		System.out.println(s);
		System.out.println("Total characters : "+ctr);
	}

}
