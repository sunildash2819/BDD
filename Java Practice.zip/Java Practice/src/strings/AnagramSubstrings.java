package strings;

import java.util.Arrays;

public class AnagramSubstrings {

	public static void main(String[] args) {
		String s1 = "AAABABAA", s2="AABA";
		int l1=s1.length();
		int l2=s2.length();
		for(int i=0;i<(l1-l2+1);i++) {
			String s = s1.substring(i, i+4);
			boolean isAnagram=checkAnagram(s, s2);
			if(isAnagram) {
				System.out.println("Found at index : "+i);
			}
		}
	}
	public static boolean checkAnagram(String s1, String s2) {
		if(s1.length()!=s2.length()) {
			return false;
		}
		char[] ch1 = s1.toCharArray();
		char[] ch2 = s2.toCharArray();
		Arrays.sort(ch1);
		Arrays.sort(ch2);
		if(Arrays.equals(ch1, ch2))
			return true;
		else
			return false;
	}

}
