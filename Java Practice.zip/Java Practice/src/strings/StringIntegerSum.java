package strings;

public class StringIntegerSum {

	public static void main(String[] args) {
		String s = "AC2BEW3";
		int l = s.length();
		int sum = 0;
		String str = "";
		for (char c = 'A'; c < 'Z'; c++) {
			for (int i = 0; i < l; i++) {
				if (s.charAt(i) == c) {
					str += s.charAt(i);
				}
			}
		}
		for (int i = 0; i < l; i++) {
			if (Character.isDigit(s.charAt(i))) {
				sum += Integer.parseInt(String.valueOf(s.charAt(i)));
			}
		}
		str = str + sum;
		System.out.println(str);
	}

}
