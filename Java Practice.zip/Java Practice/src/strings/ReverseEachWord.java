package strings;

import java.util.Stack;

public class ReverseEachWord {

	public static void main(String[] args) {
		String s = "geeks quiz practice code";
		String[] words = s.split(" ");
		for(int i=0;i<words.length;i++) {
			words[i]=reverse(words[i]);
		}
		for(int i=0;i<words.length;i++) {
			System.out.print(words[i]+" ");
		}
	}
	
	public static String reverse(String s) {
		char[] ch = s.toCharArray();
		Stack<Character> st = new Stack<>();
		for(int i=0;i<ch.length;i++) {
			st.push(ch[i]);
		}
		for(int i=0;i<ch.length;i++) {
			ch[i]=st.peek();
			st.pop();
		}
		s=String.valueOf(ch);
		return s;
	}
}
