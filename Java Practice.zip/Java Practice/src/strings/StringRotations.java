package strings;

public class StringRotations {
	
	public static void leftRotate(String s,int k) {
		String str = s.substring(k)+s.substring(0, k);
		System.out.println("Left rotation : "+str);
	}
	
	public static void rightRotate(String s,int k) {
		String str = s.substring(s.length()-k,s.length())+s.substring(0,s.length()-k);
		System.out.println("Right rotation : "+str);
	}

	public static void main(String[] args) {
		String s = "GeeksForGeeks";
		leftRotate(s, 2);
		rightRotate(s, 2);
	}

}
