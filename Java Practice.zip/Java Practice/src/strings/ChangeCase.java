package strings;

public class ChangeCase {

	public static void main(String[] args) {
		String s = "Hello World";
		int len = s.length();
		/*StringBuffer sb = new StringBuffer(s);
		for(int i=0;i<len;i++) {
			if(Character.isUpperCase(s.charAt(i))){
				sb.setCharAt(i, Character.toLowerCase(s.charAt(i)));
			}
			else {
				sb.setCharAt(i, Character.toUpperCase(s.charAt(i)));
			}
		}
		System.out.println(s);
		System.out.println(sb);*/
		char[] ch = s.toCharArray();
		for(int i=0;i<ch.length;i++) {
			if(Character.isUpperCase(ch[i]))
				ch[i]=Character.toLowerCase(ch[i]);
			else
				ch[i]=Character.toUpperCase(ch[i]);
		}
		System.out.println(s);
		s=String.valueOf(ch);
		System.out.println(s);
	}

}
