package strings;

public class DivideStringsInEqualParts {

	public static void main(String[] args) {
		String s = "aaabbbbbcccc";
		int n = 3;
		int len = s.length();
		System.out.println(len);
		int m = len / n;
		if (len % n != 0) {
			System.out.println("String cannot be divided into n parts");
		} else {
			String[] newString = new String[n];
			int temp = 0;
			for (int i = 0; i < len; i += m) {
				newString[temp] = s.substring(i, i + m);
				temp++;
			}
			for (int i = 0; i < newString.length; i++) {
				System.out.println(newString[i]);
			}
		}
	}

}
