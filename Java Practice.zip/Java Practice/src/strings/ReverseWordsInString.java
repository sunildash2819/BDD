package strings;

import java.util.Arrays;
import java.util.Stack;

public class ReverseWordsInString {

	public static void main(String[] args) {
		String s = "geeks quiz practice code";
		String[] words = s.split(" ");
		/*String temp="";
		for(int i=0,j=words.length-1;i<j;i++,j--) {
			temp=words[i];
			words[i]=words[j];
			words[j]=temp;
		}
		s=Arrays.toString(words);
		System.out.println(s);*/
		Stack<String> st = new Stack<>();
		for(String word:words) {
			st.push(word);
		}
		
		for(int i=0;i<words.length;i++) {
			words[i]=st.peek();
			st.pop();
		}
		for(int i=0;i<words.length;i++) {
			System.out.print(words[i]+" ");
		}
	}

}
