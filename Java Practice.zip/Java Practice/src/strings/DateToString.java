package strings;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateToString {

	public static void main(String[] args) {
		Date date = new Date();
		DateFormat df = new SimpleDateFormat("DD-mm-YYYY");
		Date today = Calendar.getInstance().getTime();
		String dateToString = df.format(date);
		System.out.println(dateToString);
	}

}
