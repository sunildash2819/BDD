package strings;

public class UncommonCharacters {

	public static void main(String[] args) {
		String s1 = "geeksforgeeks", s2 = "geeksquiz";
		for (char ch = 'a'; ch <= 'z'; ch++) {
			String s = String.valueOf(ch);
			if(s1.contains(s) || s2.contains(s)) {
				if((!(s1.contains(s))) || (!(s2.contains(s)))) {
					System.out.print(s+" ");
				}
			}
			/*else if(s2.contains(s)) {
				if(!(s1.contains(s))) {
					System.out.print(s+" ");
				}
			}*/
		}
	}
}
