package strings;

import java.util.LinkedHashMap;
import java.util.Map.Entry;

public class SecondMostRepeatedWord {

	public static void main(String[] args) {
//		String arr[] = { "ccc", "aaa", "ccc", "ddd", "ccc", "aaa" };
		String arr[] = { "geeks", "for", "geeks", "be", 
                "portal", "to", "learn", "can", "be", 
                "computer", "science", "zoom", "yup", 
                "fire", "in", "be", "data", "geeks" };
		LinkedHashMap<String, Integer> map = new LinkedHashMap<>();
		int l = arr.length;
		int max=Integer.MIN_VALUE, sec_max=Integer.MIN_VALUE;
		String maxRepeatedWord="";
		for (int i = 0; i < l; i++) {
			if (!(map.containsKey(arr[i])))
				map.put(arr[i], 1);
			
			else if(map.containsKey(arr[i]))
				map.put(arr[i], map.get(arr[i])+1);

		}
		
		System.out.println(map);
		
		for(Entry<String, Integer> e : map.entrySet()) {
			int value=e.getValue();
			if(value>max) {
				max=value;
			}
		}
		for(Entry<String, Integer> e : map.entrySet()) {
			int value=e.getValue();
			if(value==max) {
				maxRepeatedWord=e.getKey();
				System.out.println(maxRepeatedWord);
			}
		}
		
		
		//2nd most repeated string
		/*for(Entry<String, Integer> e : map.entrySet()) {
			int value=e.getValue();
			if(value>max) {
				sec_max=max;
				max=value;
			}
			else if(value>sec_max && value!=max) {
				sec_max=value;
			}
		}
		for(Entry<String, Integer> e : map.entrySet()) {
			int value=e.getValue();
			if(value==sec_max) {
				maxRepeatedWord=e.getKey();
			}
		}
		System.out.println(maxRepeatedWord);*/
	}
}
