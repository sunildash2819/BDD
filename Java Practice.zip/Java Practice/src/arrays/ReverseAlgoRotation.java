package arrays;

public class ReverseAlgoRotation {

	public void rotate(int arr[], int rf) {
		if(rf==0)
			return;
		int size=arr.length;
		rf=rf%size;
		reverseArray(arr, 0, rf-1);
		reverseArray(arr, rf, size-1);
		reverseArray(arr, 0, size-1);
	}
	public void reverseArray(int arr[], int start, int end) {
		int temp;
		while(start<end) {
			temp=arr[start];
			arr[start]=arr[end];
			arr[end]=temp;
			start++;
			end--;
		}
	}
	public void printArray(int arr[]) {
		for(int i=0;i<arr.length;i++) {
			System.out.print(arr[i]+" ");
		}
		System.out.println();
	}
	public static void main(String[] args) {
		ReverseAlgoRotation obj = new ReverseAlgoRotation();
		int arr[] = {1,2,3,4,5,6,7};
		System.out.println("Array before rotation:");
		obj.printArray(arr);
		obj.rotate(arr, 2);
		System.out.println("Array after rotation:");
		obj.printArray(arr);
	}

}
