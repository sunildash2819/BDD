package arrays;

import java.util.Arrays;

public class SumPairClosestToZero {
	
	public void minsSumPair(int arr[]) {
		int n=arr.length;
		int sum,minSum=Integer.MAX_VALUE;
		int l=0,r=n-1;
		int min_l = l, min_r = n-1;
		Arrays.sort(arr);
		while(l<r) {
			sum=arr[l]+arr[r];
			if(Math.abs(sum)<Math.abs(minSum)) {
				minSum=sum;
				min_l=l;
				min_r=r;
			}
			if(sum<0)
				l++;
			else
				r--;
		}
		System.out.println("Two elements whose sum is minimum are : "+ arr[min_l] + " and "+ arr[min_r]);
	}

	public static void main(String[] args) {
		SumPairClosestToZero obj = new SumPairClosestToZero();
		int arr[] = {1, 60, -10, 70, -80, 85};
		obj.minsSumPair(arr);
	}

}
