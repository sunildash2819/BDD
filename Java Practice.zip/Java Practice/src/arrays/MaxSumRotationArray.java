package arrays;

public class MaxSumRotationArray {
	
	public void findMaxSum(int arr[]) {
		int n=arr.length;
		int arrSum=0, currValSum=0, maxSum;
		for(int i=0;i<n;i++) {
			arrSum=arrSum+arr[i];
			currValSum=currValSum+(i*arr[i]);
		}
		maxSum=currValSum;
		for(int j=1;j<n;j++) {
			currValSum=currValSum+arrSum-n*arr[n-j];
			if(currValSum>maxSum)
				maxSum=currValSum;
		}
		System.out.println("Max sum : "+maxSum);
	}

	public void findSum(int arr[]) {
		int rotSum,maxSum=0;
		int n=arr.length;
		for(int i=0;i<n;i++) {
			arr=rotateArray(arr);
			rotSum=0;
			for(int j=0;j<n;j++) {
				rotSum=rotSum+(j*arr[j]);
			}
			if(rotSum>maxSum)
				maxSum=rotSum;
		}
		System.out.println("Max sum : "+maxSum);
	}
	public int[] rotateArray(int arr[]) {
		int n=arr.length;
		int temp=arr[n-1];
		for(int i=n-1;i>0;i--) {
			arr[i]=arr[i-1];
		}
		arr[0]=temp;
		return arr;
	}
	public static void main(String[] args) {
		MaxSumRotationArray obj = new MaxSumRotationArray();
		int arr[] = {10, 1, 2, 3, 4, 5, 6, 7, 8, 9};
		obj.findMaxSum(arr);
		obj.findSum(arr);
	}

}
