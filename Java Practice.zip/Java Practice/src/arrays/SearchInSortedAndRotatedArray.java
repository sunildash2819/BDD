package arrays;

public class SearchInSortedAndRotatedArray {

	public static void main(String[] args) {
		SearchInSortedAndRotatedArray obj = new SearchInSortedAndRotatedArray();
		int arr[] = { 5, 6, 7, 8, 9, 10, 1, 2, 3 };
		int key = 3;
		obj.printArray(arr);
		obj.searchSortedRotatedArray(arr, arr.length, key);
	}

	public void printArray(int arr[]) {
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
		System.out.println();
	}

	public void searchSortedRotatedArray(int[] arr, int length, int key) {
		int pivot = findPivot(arr, length);
		if (pivot == -1)
			binarySearch(arr, 0, length - 1, key);
		else if (arr[pivot] == key)
			System.out.println("Element " + key + " found at position " + (pivot + 1));
		else if (arr[0] <= key)
			binarySearch(arr, 0, pivot - 1, key);
		else
			binarySearch(arr, pivot + 1, length - 1, key);
	}

	public void binarySearch(int arr[], int low, int high, int key) {
		int mid = (low + high) / 2;
		while (low <= high) {
			if (arr[mid] == key) {
				System.out.println("Element " + key + " found at position " + (mid + 1));
				break;
			} else if (arr[mid] > key)
				high = mid - 1;
			else if (arr[mid] < key)
				low = mid + 1;
			mid = (low + high) / 2;
		}
		if (low > high)
			System.out.println("Element " + key + " not found");
	}

	public int findPivot(int arr[], int length) {
		int pivot = -1;
		for (int i = 0; i < length - 1; i++) {
			if (arr[i] <= arr[i + 1]) {
				continue;
			} else {
				pivot = i;
				break;
			}
		}
		return pivot;
	}

}
