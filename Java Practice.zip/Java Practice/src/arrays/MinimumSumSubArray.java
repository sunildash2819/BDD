package arrays;

public class MinimumSumSubArray {
	
	public void findMinSumSubArray(int arr[], int k) {
		int n=arr.length;
		int startIndex,endIndex,currSum;
		int minSum=Integer.MAX_VALUE;
		int resIndex=0;
		for(int i=0;i<=n-k;i++) {
			startIndex=i;
			endIndex=i+(k-1);
			currSum=0;
			for(int j=startIndex;j<=endIndex;j++) {
				currSum+=arr[j];
			}
			if(currSum<minSum) {
				minSum=currSum;
				resIndex=i;
			}
		}
		printMinSubArray(arr, resIndex, resIndex+(k-1));
		System.out.println("\nMinimum Sum : "+minSum);
	}
	public void printMinSubArray(int arr[],int start, int end) {
		System.out.println("Minimum Sub-array : ");
		for(int i=start;i<=end;i++) {
			System.out.print(arr[i]+"\t");
		}
	}

	public static void main(String[] args) {
		MinimumSumSubArray obj = new MinimumSumSubArray();
		int arr[] = {3,7,5,20,-10,0,12};
		int k=2;
		obj.findMinSumSubArray(arr, k);
	}
}
