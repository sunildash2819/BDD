package arrays;

public class MergeOperationPalindromeArray {
	
	public void findMergeOperations(int arr[]) {
		int n=arr.length;
		int ans=0;
		for(int i=0,j=n-1;i<=j;) {
			if(arr[i]==arr[j]) {
				i++;
				j--;
			}
			else if(arr[i]>arr[j]) {
				j--;
				arr[j]=arr[j]+arr[j+1];
				ans++;
			}
			else {
				i++;
				arr[i]=arr[i]+arr[i-1];
				ans++;
			}
		}
		for(int i=0;i<arr.length;i++) {
			System.out.print(arr[i]+" ");
		}
		System.out.println();
		System.out.println("Minimum number of merge Operation : "+ans);
	}

	public static void main(String[] args) {
		MergeOperationPalindromeArray obj = new MergeOperationPalindromeArray();
		int arr[]= {1,4,5,9,1};
		obj.findMergeOperations(arr);
	}

}
