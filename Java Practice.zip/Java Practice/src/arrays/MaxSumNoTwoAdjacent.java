package arrays;

public class MaxSumNoTwoAdjacent {

	public void findMaxSum(int arr[]) {
		int n=arr.length;
		int incl=arr[0];
		int excl=0;
		int exclNew;
		for(int i=1;i<n;i++) {
			exclNew=(incl>excl)?incl:excl;
			incl=excl+arr[i];
			excl=exclNew;
		}
		int maxSum=(incl>excl)?incl:excl;
		System.out.println("Max sum : "+maxSum);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
