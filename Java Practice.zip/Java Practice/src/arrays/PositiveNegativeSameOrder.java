package arrays;

public class PositiveNegativeSameOrder {

	public void rearrange(int arr[]) {
		int n = arr.length;
		int tempArr[] = new int[n];
		int i, j = 0;
		int np, pp;
		for (i = 0; i < n; i++) {
			if (arr[i] < 0) {
				tempArr[j] = arr[i];
				j++;
			}
		}
		pp = j;
		for (i = 0; i < n; i++) {
			if (arr[i] > 0) {
				tempArr[j] = arr[i];
				j++;
			}
		}
		int nc, pc, lc;
		nc = pp;
		pc = n - nc;
		if (pc > nc)
			lc = nc;
		else
			lc = pc;

		np = 0;
		i = 0;
		j = 0;
		for (i = 0; i < lc; i++) {
			arr[j] = tempArr[np];
			arr[j + 1] = tempArr[pp];
			np++;
			pp++;
			j += 2;
		}

		if (pc > nc)
			i = pp;
		else
			i = np;

		while (i < n) {
			arr[i] = tempArr[i];
			i++;
		}
		for (i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
	}

	public static void main(String[] args) {
		PositiveNegativeSameOrder obj = new PositiveNegativeSameOrder();
		int arr[] = { 2, -4, -2, 3, 4, -3, -1 };
		obj.rearrange(arr);

	}

}
