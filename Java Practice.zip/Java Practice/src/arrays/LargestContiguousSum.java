package arrays;

public class LargestContiguousSum {

	public void largestContiguousSum(int arr[]) {
		int n=arr.length;
		int maxSoFar=0,maxEndHere=0;
		for(int i=0;i<n;i++) {
			maxEndHere=maxEndHere+arr[i];
			if(maxSoFar<maxEndHere)
				maxSoFar=maxEndHere;
			if(maxEndHere<0)
				maxEndHere=0;
		}
		System.out.println("Largest contiguous sum : "+maxSoFar);
	}
	public static void main(String[] args) {
		LargestContiguousSum obj = new LargestContiguousSum();
		int [] arr = {2,-3, 4, -1, -2, 1, 5, -3};
		obj.largestContiguousSum(arr);
	}

}
