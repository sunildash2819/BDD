package arrays;

import java.util.Arrays;

public class RearrangeEvenOddPosition {

	public void arrangeArray(int arr[]) {
		int n=arr.length;
		int tempArr[]= new int[n];
		for(int i = 0;i<n;i++) {
			tempArr[i]=arr[i];
		}
		Arrays.sort(tempArr);
		int evenPos=n/2;
		int oddPos=n-evenPos;
		int j=oddPos-1;
		for(int i=0;i<n;i+=2) {
			arr[i]=tempArr[j];
			j--;
		}
		j=oddPos;
		for(int i=1;i<n;i+=2) {
			arr[i]=tempArr[j];
			j++;
		}
		for(int i=0;i<arr.length;i++) {
			System.out.print(arr[i]+" ");
		}
	}
	public static void main(String[] args) {
		RearrangeEvenOddPosition obj = new RearrangeEvenOddPosition();
		int arr[]= {1,2,3,4,5,6,7};
		obj.arrangeArray(arr);

	}

}
