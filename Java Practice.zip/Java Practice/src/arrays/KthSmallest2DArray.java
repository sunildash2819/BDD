package arrays;

public class KthSmallest2DArray {
	
	public void kthSmallest(int arr[][],int k) {
		int n=arr.length;
		int tempArr[]=new int[n*n];
		int ctr=0;
		for(int i=0;i<n;i++) {
			for(int j=0;j<n;j++) {
				tempArr[ctr]=arr[i][j];
				ctr++;
			}
		}
		tempArr=sort(tempArr);
		for(int i=0;i<tempArr.length;i++) {
			System.out.print(tempArr[i]+" ");
		}
		System.out.println("\n"+k+"th smallest element : "+tempArr[k-1]);
	}
	
	public int[] sort(int arr[]) {
		int n=arr.length;
		int i,j,temp;
		for(i=0;i<n-1;i++) {
			for(j=0;j<n-i-1;j++) {
				if(arr[j]>arr[j+1]) {
					temp=arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=temp;
				}
			}
		}
		
		return arr;
	}

	public static void main(String[] args) {
		KthSmallest2DArray obj = new KthSmallest2DArray();
		int arr[][] = { { 10, 20, 30, 40 },
                { 15, 25, 35, 45 },
                { 25, 29, 37, 48 },
                { 32, 33, 39, 50 } };
                 
		obj.kthSmallest(arr, 7);
	}

}
