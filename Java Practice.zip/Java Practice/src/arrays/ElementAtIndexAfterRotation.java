package arrays;

public class ElementAtIndexAfterRotation {
	
	public void findElement(int arr[], int range[][],int index,int rotation) {
		int i,start,end;
		for(i=0;i<rotation;i++) {
			start=range[i][0];
			end=range[i][1];
			arr=rotate(arr,start,end);
		}
		for(i=0;i<arr.length;i++) {
			System.out.print(arr[i]+" ");
		}
		System.out.println();
		System.out.println("Element at index "+index+" is "+arr[index]);
	}
	public int[] rotate(int arr[], int start, int end) {
		int temp=arr[end];
		for(int i=end;i>start;i--) {
			arr[i]=arr[i-1];
		}
		arr[start]=temp;
		
		return arr;
	}

	public static void main(String[] args) {
		ElementAtIndexAfterRotation obj = new ElementAtIndexAfterRotation();
		int arr[]= {1,2,3,4,5,6,7,8};
		int range[][]= {{2,4},{0,3}};
		int index=3;
		obj.findElement(arr, range, index, 2);
	}

}
