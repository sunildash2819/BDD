package arrays;

import java.util.Arrays;

public class CountPairsWithDiff {
	
	public void countPairs(int a[], int k) {
		int n=a.length;
		int ctr=0,l=0,r=0;
		Arrays.sort(a);
		while(r<n) {
			if(a[r]-a[l]==k) {
				ctr++;
				l++;
				r++;
			}
			else if(a[r]-a[l]<k)
				r++;
			else
				l++;
		}
		System.out.println("Total pairs : "+ctr);
	}

	public static void main(String[] args) {
		CountPairsWithDiff obj = new CountPairsWithDiff();
		int a[]= {1,3,5,4,2,2};
		int k=3;
		obj.countPairs(a, k);
	}

}
