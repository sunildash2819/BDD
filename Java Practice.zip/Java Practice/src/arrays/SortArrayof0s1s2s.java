package arrays;

public class SortArrayof0s1s2s {

	static int j=0;
	public void sort(int a[]) {
		int n = a.length;
		int c0 = 0, c1 = 0, c2 = 0;
		for (int i = 0; i < n; i++) {
			if (a[i] == 0)
				c0++;
			else if (a[i] == 1)
				c1++;
			else
				c2++;
		}
		a=reArranArray(a,c0-1, 0);
		a=reArranArray(a,c0+c1-1, 1);
		a=reArranArray(a,c0+c1+c2-1, 2);
		printArray(a);
	}

	public void printArray(int arr[]) {
		for(int i=0;i<arr.length;i++) {
			System.out.print(arr[i]+" ");
		}
		System.out.println();
	}
	
	public int[] reArranArray(int a[],int n,int value) {
		int i;
		for (i = j; i <= n; i++) {
			a[i]=value;
		}
		j=i;
		return a;
	}

	public static void main(String[] args) {
		SortArrayof0s1s2s obj = new SortArrayof0s1s2s();
		int a[]={ 0, 1, 1, 0, 1, 2, 1, 2, 0, 0, 0, 1 };
		obj.sort(a);
	}

}
