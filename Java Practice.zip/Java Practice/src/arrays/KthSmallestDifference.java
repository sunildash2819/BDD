package arrays;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class KthSmallestDifference {
	
	public void findKthSmallestDiff(int arr[], int k) {
		int n=arr.length,key,d;
		Arrays.sort(arr);
		List<Integer> differenceList = new ArrayList<Integer>();
		for(int i=0;i<n-1;i++) {
			key=arr[i];
			for(int j=i+1;j<n;j++) {
				d=arr[j]-key;
				differenceList.add(d);
			}
		}
		for(int i=0;i<arr.length;i++) {
			System.out.print(arr[i]+" ");
		}
		Collections.sort(differenceList);
		System.out.println("\nAbsolute differences:");
		for(int i:differenceList) {
			System.out.print(i+" ");
		}
		System.out.println("\nKth smallest difference at position "+k+" : "+differenceList.get(k-1));
	}

	public static void main(String[] args) {
		KthSmallestDifference obj = new KthSmallestDifference();
		int arr[]= {3,2,4,1};
		obj.findKthSmallestDiff(arr, 3);
	}

}
