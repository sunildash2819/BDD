package arrays;

public class RotationCount {

	public void countRotation(int arr[]) {
		int n=arr.length;
		int min=arr[0],minIndex=0;
		for(int i=1;i<n;i++) {
			if(arr[i]<min)
			{
				min=arr[i];
				minIndex=i;
			}
		}
		System.out.println("Number of rotation : "+minIndex);
	}
	public static void main(String[] args) {
		RotationCount obj = new RotationCount();
		int arr[] = {7, 9, 11, 12, 15};
		obj.countRotation(arr);
	}

}
