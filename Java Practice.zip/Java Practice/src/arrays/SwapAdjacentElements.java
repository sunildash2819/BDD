package arrays;

import java.util.Arrays;

public class SwapAdjacentElements {
	
	public void swap(int A[], boolean B[]) {
		int n=A.length;
		int i,j;
		for(i=0;i<n-1;i++) {
			if(B[i]) {
				j=i;
				while(B[j] && j<B.length-1) {
					j++;
				}
				Arrays.sort(A, i, 1+j);
				i=j;
			}
		}
		int flag=0;
		for(i=0;i<n;i++) {
			if(A[i]!=i+1) {
				flag=1;
			}
		}
		if(flag==0)
			System.out.println("Array can be sorted");
		else
			System.out.println("Array cannot be sorted");
	}

	public static void main(String[] args) {
		SwapAdjacentElements obj = new SwapAdjacentElements();
		int A[] = {3, 1, 2, 4, 5, 6};
        boolean B[] = { false, true, true, true, true };
        obj.swap(A, B);
	}

}
