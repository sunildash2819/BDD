package arrays;

public class MinElementSortedRotatedArray {
	
	public int findMin(int arr[], int low, int high) {
		int min=0;
		if(high<low)
			min=arr[0];
		if(high==low)
			min=arr[low];
		int mid=(low+high)/2;
		if(mid<high && arr[mid]>arr[mid+1])
			min=arr[mid+1];
		if(mid>low && arr[mid]<arr[mid-1])
			min=arr[mid];
		if(arr[high]>=arr[mid]) {
			findMin(arr, low, mid-1);
		}
		else {
			findMin(arr, mid+1, high);
		}
		
		return min;
	}

	public static void main(String[] args) {
		MinElementSortedRotatedArray obj = new MinElementSortedRotatedArray();
		int arr[] = {7, 9, 11, 12, 15};
		int min=obj.findMin(arr,0,arr.length-1);
		System.out.println("Minimum element : "+min);
	}

}
