package arrays;

import java.util.Scanner;
import java.util.StringTokenizer;

public class ArrayRotation {
	
	int arr[], size;
	Scanner sc = new Scanner(System.in);
	public void initializeArray() {
		System.out.println("Enter size of the array: ");
		size=sc.nextInt();
		arr=new int[size];
		System.out.println("Enter array elements: ");
		for(int i=0;i<size;i++) {
			arr[i]=sc.nextInt();
		}
	}
	public void leftRotate() {
		System.out.println("Enter number of times rotation: ");
		int r=sc.nextInt();
		int n=arr.length;
		int i,j,temp;
		for(i=1;i<=r;i++) {
			temp=arr[0];
			for(j=0;j<n-1;j++) {
				arr[j]=arr[j+1];
			}
			arr[j]=temp;
		}
	}
	public void printArray() {
		for(int i=0;i<arr.length;i++) {
			System.out.print(arr[i]+" ");
		}
		System.out.println();
	}
	public static void main(String[] args) {
		ArrayRotation arrRotation = new ArrayRotation();
		arrRotation.initializeArray();
		System.out.println("Array elements before rotation");
		arrRotation.printArray();
		arrRotation.leftRotate();
		System.out.println("Array elements after rotation");
		arrRotation.printArray();
	}

}
