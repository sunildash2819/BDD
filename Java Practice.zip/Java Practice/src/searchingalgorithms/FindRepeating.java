package searchingalgorithms;

public class FindRepeating {
	
	public void findRepeatElement(int a[]) {
		int n=a.length;
		int sum=0,repeatEle;
		for(int i=0;i<n;i++) {
			sum+=a[i];
		}
		repeatEle=sum-((n*(n-1))/2);
		System.out.println("The repeating element : "+repeatEle);
	}

	public static void main(String[] args) {
		FindRepeating obj = new FindRepeating();
		int[] a = { 9, 1, 2, 6, 1, 8, 5, 3, 4, 7 };
		obj.findRepeatElement(a);
	}

}
