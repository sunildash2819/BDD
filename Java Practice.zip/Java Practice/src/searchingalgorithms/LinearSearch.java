package searchingalgorithms;

import java.util.Scanner;

public class LinearSearch {

	public static void main(String[] args) {
		int arr[] = new int[10];
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter array elements: ");
		for (int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		System.out.println("Enter element to be searched");
		int ele = sc.nextInt();
		sc.close();
		int flag = 0;
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] == ele) {
				flag = 1;
				System.out.println("The element is found at position " + (i + 1));
			}
		}
		if (flag == 0) {
			System.out.println("The element is not found in the array");
		}
	}
}
