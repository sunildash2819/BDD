package searchingalgorithms;

public class SubArrayWithGivenSum {
	
	public void findSubArray(int a[],int sum) {
		int n=a.length;
		int currSum=a[0],start=0,flag=0;
		for(int i=1;i<=n;i++) {
			while(currSum>sum && start<i-1) {
				currSum-=a[start];
				start++;
			}
			if(currSum==sum) {
				System.out.println("The sub-array with sum "+sum+" is found between index "+start+" and "+(i-1));
				flag=1;
				break;
			}
			if(i<n)
				currSum+=a[i];
		}
		if(flag==0)
			System.out.println("No sub-array with the given sum is found");
	}

	public static void main(String[] args) {
		SubArrayWithGivenSum obj = new SubArrayWithGivenSum();
		int arr[] = { 15, 2, 4, 8, 9, 5, 10, 23 }; 
        int sum = 23; 
        obj.findSubArray(arr, sum); 
	}

}
