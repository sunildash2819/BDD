package searchingalgorithms;

public class EquilibriumIndex {
	
	public void findEquilibriumIndex(int a[]) {
		int n=a.length;
		int sum=0,leftSum=0;
		int eqIndex=-1;
		for(int i=0;i<n;i++) {
			sum+=a[i];
		}
		for(int i=0;i<n;i++) {
			sum-=a[i];
			if(leftSum==sum) {
				eqIndex=i;
				break;
			}
			leftSum+=a[i];
		}
		if(eqIndex!=-1)
			System.out.println("Equilibrium index found at "+eqIndex);
		else
			System.out.println("There is no equilibrium index");
	}

	public static void main(String[] args) {
		EquilibriumIndex obj = new EquilibriumIndex();
		int a[] = { -7, 1, 1, 2, -4, 3, 0 }; 
		obj.findEquilibriumIndex(a);
	}

}
