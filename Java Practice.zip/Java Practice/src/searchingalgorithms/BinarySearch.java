package searchingalgorithms;

import java.util.Scanner;

public class BinarySearch {

	public static void main(String[] args) {
		int arr[] = new int[10];
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter array elements: ");
		for (int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		char s;
		boolean b;
		do {
			System.out.println("Enter element to be searched");
			int ele = sc.nextInt();
			new BinarySearch().binarySearch(arr, 0, arr.length-1, ele);
			System.out.println("Do you want to continue? Y-Yes and N-No");
			s=sc.next().charAt(0);
			if(s=='Y')
				b=true;
			else
				b=false;
		} while (b);
		sc.close();
	}
	
	public void binarySearch(int arr[],int first, int last, int key) {
		int mid=(first+last)/2;
		while(first<=last) {
			if(arr[mid]==key) {
				System.out.println("Element is found at position "+(mid+1));
				break;
			}
			else if(arr[mid]<key)
				first=mid+1;
			else if(arr[mid]>key)
				last=mid-1;
			
			mid=(first+last)/2;
		}
		if(first>last)
			System.out.println("Element not found");
	}

}
