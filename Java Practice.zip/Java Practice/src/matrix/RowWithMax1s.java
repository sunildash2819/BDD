package matrix;

public class RowWithMax1s {
	
	public void findRowWithMax1s(int a[][]) {
		int n=a.length;
		int max=Integer.MIN_VALUE;
		int ctr,maxRow = 0;
		int i,j;
		for(i=0;i<n;i++) {
			j=0;
			ctr=0;
			while(j<n) {
				if(a[i][j]==1)
					ctr++;
				j++;
			}
			if(ctr>max) {
				max=ctr;
				maxRow=i;
			}
		}
		if(maxRow==0)
			System.out.println("There is no 1s in the matrix");
		else
			System.out.println("Row with max 1s : "+(maxRow+1));
	}

	public static void main(String[] args) {
		RowWithMax1s obj = new RowWithMax1s();
		int mat[][] = { { 0, 0, 0, 1 }, 
                { 0, 1, 1, 1 }, 
                { 1, 1, 1, 1 }, 
                { 0, 0, 0, 0 } };  
		obj.findRowWithMax1s(mat);
	}

}
