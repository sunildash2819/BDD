/**
  1, 2, 3
  3, 1, 2
  2, 3, 1
 */
package matrix;

public class PermutedMatrix {

	public boolean isPermutedMatrix(int a[][]) {
		int n = a.length;
		String str_cat = "", curr_str = "";
		for (int i = 0; i < n; i++) {
			str_cat = str_cat + String.valueOf(a[0][i]);
		}
		str_cat = str_cat + str_cat;
		for (int i = 1; i < n; i++) {
			curr_str = "";
			for (int j = 0; j < n; j++) {
				curr_str = curr_str + String.valueOf(a[i][j]);
			}
			if (!(str_cat.contains(curr_str)))
				return false;
		}
		return true;
	}

	public static void main(String[] args) {
		PermutedMatrix obj = new PermutedMatrix();
		int mat[][] = { { 1, 2, 3, 4 }, { 4, 1, 2, 3 }, { 3, 4, 1, 2 }, { 2, 3, 4, 1 } };
		if (obj.isPermutedMatrix(mat)) {
			System.out.println("Yes");
		} else {
			System.out.println("No");
		}
	}

}
