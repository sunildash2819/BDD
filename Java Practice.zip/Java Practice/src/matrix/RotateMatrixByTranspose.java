package matrix;

public class RotateMatrixByTranspose {
	
	public int[][] rotate(int a[][]) {
		a=transpose(a);
		a=reverseColumn(a);
		return a;
	}
	
	public void printMatrix(int[][] a) {
		for(int i=0;i<a.length;i++) {
			for(int j=0;j<a[0].length;j++) {
				System.out.print(a[i][j]+" ");
			}
			System.out.println();
		}
	}

	public int[][] reverseColumn(int[][] a) {
		int temp;
		for(int i=0;i<a.length;i++) {
			for(int j=0,k=a.length-1;j<k;j++,k--) {
				temp=a[j][i];
				a[j][i]=a[k][i];
				a[k][i]=temp;
			}
		}
		return a;
	}

	public int[][] transpose(int a[][]) {
		int temp;
		for(int i=0;i<a.length;i++) {
			for(int j=i;j<a[0].length;j++) {
				temp=a[i][j];
				a[i][j]=a[j][i];
				a[j][i]=temp;
			}
		}
		return a;
	}

	public static void main(String[] args) {
		RotateMatrixByTranspose obj = new RotateMatrixByTranspose();
		int a[][]= {{1,2,3},
					{4,5,6},
					{7,8,9}
					};
		a=obj.rotate(a);
		/*To rotate matrix by 180, call rotate method again*/
		//a=obj.rotate(a);
		obj.printMatrix(a);
	}

}
