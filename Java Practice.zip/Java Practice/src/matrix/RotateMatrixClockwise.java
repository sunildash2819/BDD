package matrix;

public class RotateMatrixClockwise {
	
	public void rotate(int a[][], int m, int n) {
		int row=0,col=0;
		int prev,curr;
		while(row<m && col<n) {
			if(row+1 == m || col+1 == n)
				break;
			prev=a[row+1][col];
			for(int i=col;i<n;i++) {
				curr=a[row][i];
				a[row][i]=prev;
				prev=curr;
			}
			row++;
			for(int i=row;i<m;i++) {
				curr=a[i][n-1];
				a[i][n-1]=prev;
				prev=curr;
			}
			n--;
			if(row<m) {
				for(int i=n-1;i>=col;i--) {
					curr=a[m-1][i];
					a[m-1][i]=prev;
					prev=curr;
				}
			}
			m--;
			if(col<n) {
				for(int i=m-1;i>=row;i--) {
					curr=a[i][col];
					a[i][col]=prev;
					prev=curr;
				}
			}
			col++;
		}
		printMatrix(a);
	}
	public void printMatrix(int a[][]) {
		for(int i=0;i<a.length;i++) {
			for(int j=0;j<a[0].length;j++) {
				System.out.print(a[i][j]+" ");
			}
			System.out.println();
		}
	}

	public static void main(String[] args) {
		RotateMatrixClockwise obj = new RotateMatrixClockwise();
		int a[][]= {{1,2,3,4},
				{5,6,7,8},
				{9,10,11,12},
				{13,14,15,16}};
		int c=a[0].length;
		int r=a.length;
		obj.rotate(a, r, c);
		}
	}


