package matrix;

public class MatrixMultiplication {

	public void matrixMultiply(int a[][], int b[][]) {
		int r1 = a.length, c1 = a[0].length;
		int r2 = b.length, c2 = b[0].length;
		if (c1 != r2) {
			System.out.println("Invalid Matrix");
			System.exit(0);
		}
		int c[][] = new int[r1][c2];
		for (int i = 0; i < c.length; i++) {
			for (int j = 0; j < c[i].length; j++) {
				c[i][j] = 0;
				for (int k = 0; k < c1; k++) {
					c[i][j] += a[i][k] * b[k][j];
				}
			}
		}
		System.out.println("Matrix after multiplication:");
		for (int i = 0; i < c.length; i++) {
			for (int j = 0; j < c[i].length; j++) {
				System.out.print(c[i][j] + "	");
			}
			System.out.println();
		}

	}

	public static void main(String[] args) {
		MatrixMultiplication obj = new MatrixMultiplication();
		int a[][] = { { 1, 2, 3 }, { 4, 5, 6 } };
		int b[][] = { { 1, 2, 3, 4 }, { 5, 6, 7, 8 }, { 9, 10, 11, 12 } };
		obj.matrixMultiply(a, b);
	}

}
