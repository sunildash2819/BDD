package matrix;

public class PrintSpiralMatrix {
	
	public void printSpiral(int a[][]) {
		int m=a.length,n=a[0].length;
		int r=0,c=0;
		while(r<m && c<n) {
			for(int i=c;i<n;i++) {
				System.out.print(a[r][i]+" ");
			}
			r++;
			for(int i=r;i<m;i++) {
				System.out.print(a[i][n-1]+" ");
			}
			n--;
			if(r<m) {
				for(int i=n-1;i>=c;i--) {
					System.out.print(a[m-1][i]+" ");
				}
				m--;
			}
			if(c<n) {
				for(int i=m-1;i>=r;i--) {
					System.out.print(a[i][c]+" ");
				}
				c++;
			}
		}
	}

	public static void main(String[] args) {
		PrintSpiralMatrix obj =new PrintSpiralMatrix();
		int a[][]= {{1,2,3,4},
				{5,6,7,8},
				{9,10,11,12},
				{13,14,15,16}};
		obj.printSpiral(a);
	}

}
