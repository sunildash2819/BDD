package matrix;

public class SwapMajorAndMinorDiagonalElements {

	public void swap(int a[][]) {
		int n = a.length;
		int temp;
		for (int i = 0; i < n; i++) {
			temp = a[i][i];
			a[i][i] = a[i][n - 1 - i];
			a[i][n - 1 - i] = temp;
		}
		printMatrix(a);
	}

	public void printMatrix(int[][] a) {
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[0].length; j++) {
				System.out.print(a[i][j] + " ");
			}
			System.out.println();
		}
	}

	public static void main(String[] args) {
		SwapMajorAndMinorDiagonalElements obj = new SwapMajorAndMinorDiagonalElements();
		int a[][] = {{0, 1, 2},  
                {3, 4, 5},  
                {6, 7, 8}};
		obj.printMatrix(a);
		System.out.println();
		obj.swap(a);
	}

}
