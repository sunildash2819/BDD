/** 
1    2    3    4    
5    6    7    8    
9    10    11    12    

9    5    1    
10    6    2    
11    7    3    
12    8    4    
*/
package matrix;

public class ChangeRowColumnAndRotate {
	

	public static void main(String[] args) {
		ChangeRowColumnAndRotate obj = new ChangeRowColumnAndRotate();
		int a[][]= {{1,2,3,4},
					{5,6,7,8},
					{9,10,11,12}
					};
		obj.rotate(a);
	}

	public void rotate(int[][] a) {
		int b[][]=new int[a[0].length][a.length];
		b=transpose(a);
		b=reverseRow(b);
		System.out.println("Array elements before rotation:");
		printMatrix(a);
		System.out.println("Array elements after rotation:");
		printMatrix(b);
	}
	
	public void printMatrix(int[][] a) {
		for(int i=0;i<a.length;i++) {
			for(int j=0;j<a[0].length;j++) {
				System.out.print(a[i][j]+" ");
			}
			System.out.println();
		}
	}

	public int[][] reverseRow(int[][] b) {
		int temp;
		for(int i=0;i<b.length;i++) {
			for(int j=0,k=b[0].length-1;j<k;j++,k--) {
				temp=b[i][j];
				b[i][j]=b[i][k];
				b[i][k]=temp;
			}
		}
		return b;
	}

	public int[][] transpose(int[][] a) {
		int b[][]=new int[a[0].length][a.length];
		for(int i=0;i<a.length;i++) {
			for(int j=0;j<a[0].length;j++) {
				b[j][i]=a[i][j];
			}
		}
		return b;
	}

}
