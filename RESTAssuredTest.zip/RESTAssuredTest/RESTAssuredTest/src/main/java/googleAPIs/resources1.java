package googleAPIs;

public class resources1 {

	//You can call method from the class name with className.method if that method is defined with static
	public static String placePostData()
	{
		
		String res="/maps/api/place/add/json";
		return res;
	}
	
	
	


}
