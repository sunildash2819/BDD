package mobiletest;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.Iterator;
import java.util.Set;

import static java.time.Duration.ofSeconds;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Platform;
import org.openqa.selenium.ScreenOrientation;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.DriverCommand;
import org.openqa.selenium.support.ui.Select;

import com.google.common.collect.ImmutableMap;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.MultiTouchAction;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.android.AndroidTouchAction;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.android.nativekey.KeyEventMetaModifier;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.touch.LongPressOptions;
import io.appium.java_client.touch.TapOptions;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.ElementOption;
import io.appium.java_client.touch.offset.PointOption;
import io.appium.java_client.touch.ActionOptions;


public class Demo {
	
	AndroidDriver<MobileElement> driver;
	
	public void setUp() throws MalformedURLException
	{
		DesiredCapabilities caps=new DesiredCapabilities();
		caps.setCapability(MobileCapabilityType.AUTOMATION_NAME, "Appium");
		caps.setCapability(MobileCapabilityType.DEVICE_NAME, "vivo 1718");
		caps.setCapability(MobileCapabilityType.PLATFORM_NAME, Platform.ANDROID);
		caps.setCapability(MobileCapabilityType.PLATFORM_VERSION, "8.1.0");
		caps.setCapability(MobileCapabilityType.BROWSER_NAME, "Chrome");
		
		driver=new AndroidDriver<>(new URL("http://127.0.0.1:4723"), caps);
		AppiumDriver<MobileElement> driver2=new AppiumDriver<MobileElement>(new URL(""), caps); 
	}
	public void test() throws IOException
	{
		TouchAction action=new TouchAction(driver);
		action.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(3)));
		MobileElement ele=driver.findElementById("");
		//tap
		action.tap(TapOptions.tapOptions().withElement(ElementOption.element(ele))).perform();
		
		//long press
		action.longPress(LongPressOptions.longPressOptions().withElement(ElementOption.element(ele))
				.withDuration(Duration.ofSeconds(3))).release().perform();
		//swipe
		MobileElement first=driver.findElementById("");;
		MobileElement second=driver.findElementById("");;
		action.longPress(LongPressOptions.longPressOptions().withElement(ElementOption.element(first))
				.withDuration(Duration.ofSeconds(2))).moveTo(ElementOption.element(second)).release().perform();
		
		MultiTouchAction multiTouch=new MultiTouchAction(driver);
		multiTouch.add(action).perform();
		
		AndroidTouchAction actions=new AndroidTouchAction(driver);
		actions.longPress(LongPressOptions.longPressOptions().withElement(ElementOption.element(first))
				.withDuration(Duration.ofSeconds(2))).release().perform();
		
		driver.pressKey(new KeyEvent(AndroidKey.BACK));
		driver.pressKey(new KeyEvent().withKey(AndroidKey.HOME));
		driver.pressKey(new KeyEvent().withKey(AndroidKey.A).withMetaModifier(KeyEventMetaModifier.CAPS_LOCK_ON));
		
		//zoom
		int x=driver.manage().window().getSize().getWidth()/2;
		int y=driver.manage().window().getSize().getHeight()/2;
		
		AndroidTouchAction action1=new AndroidTouchAction(driver);
		action1.press(new PointOption<>().withCoordinates(x-20, y-20)).moveTo(new PointOption<>().withCoordinates(x-20, y-100))
				.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(3))).release();
		
		AndroidTouchAction action2=new AndroidTouchAction(driver);
		action2.press(new PointOption<>().withCoordinates(x+20, y+20)).moveTo(new PointOption<>().withCoordinates(x+20, y+100))
				.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(3))).release();
		
		MultiTouchAction multiTouchAction=new MultiTouchAction(driver);
		multiTouchAction.add(action1).add(action2).perform();
		
		//Screen Orientation
		ScreenOrientation orientation;
		orientation=ScreenOrientation.LANDSCAPE;
		driver.execute(DriverCommand.SET_SCREEN_ORIENTATION,
				ImmutableMap.of("orientation", orientation.value().toUpperCase()));
		orientation=ScreenOrientation.PORTRAIT;
		driver.execute(DriverCommand.SET_SCREEN_ORIENTATION,
				ImmutableMap.of("orientation", orientation.value().toUpperCase()));
		
		//Screenshots
		File src=driver.getScreenshotAs(OutputType.FILE);
		File dest=new File(System.getProperty("user.dir")+"\\screeshots\\screenshot.png");
		FileUtils.copyFile(src, dest);
		
		//android.widget.Toast
		
		Set<String> contexts=driver.getContextHandles();
		Iterator<String> itr=contexts.iterator();
		while(itr.hasNext())
			System.out.println(itr.next());
		driver.context("");
	}
	
}
