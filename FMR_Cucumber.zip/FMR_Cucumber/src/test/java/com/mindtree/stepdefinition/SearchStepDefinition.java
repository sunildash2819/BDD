package com.mindtree.stepdefinition;
/**
 * @author M1049190
 * Name : Neeraja Chidambaram
 * Description : This class describes the test cases for Flat search
 * Date : 31/12/2018 
 */
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import com.mindtree.pageobjects.PgSearchPageObject;
import com.mindtree.pageobjects.SearchPageObject;

import com.mindtree.reusuablecomponents.HelperClass;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SearchStepDefinition {
	static Logger log=Logger.getLogger(SearchStepDefinition.class);
    static WebDriver driver;
    
    /*Method for opening browser and navigating to homepage*/
	@Given("^I open the browser chrome and navigate to homepage$")
	public void i_open_the_browser_chrome_and_navigate_to_homepage() throws Throwable {
		HelperClass.openBrowserAndNavigateToURL();
		log.info("Browser is opened");
			}
	/*Method to select city*/
	@When("^I select city$")
	public void i_select_city() throws Throwable {
		driver=SearchPageObject.selectCity(HelperClass.driver);
		log.info("City is selected");
		}
	/*Method to enter the location name*/
	@Then("^I enter the \"([^\"]*)\"$")
	public void i_enter_the(String locationName) throws Throwable {

		driver=SearchPageObject.enterLocation(driver,locationName);
		log.info("Location name is entered");
	    
		}
	/*Method to click on buy and click on flat*/
	@And("^I click on Buy and I click on Flat$")
	public void i_click_on_Buy_and_I_click_on_Flat() throws Throwable {
		driver=SearchPageObject.clickBuyandFlat(driver);
		log.info("Flat and Buy is clicked");
		
		}
	/*Method to click search button*/
	@And("^I click on search button$")
	public void i_click_on_search_button() throws Throwable {
		SearchPageObject.clickSearch(driver);
		log.info("Search button is clicked");
		HelperClass.closeBrowser();
		
			}
	/*Method to click on rent and click on pg*/
	@And("^I click on Rent and I click on pg$")
	public void i_click_on_Rent_and_I_click_on_pg() throws Throwable {
		driver=PgSearchPageObject.clickRentandPg(driver);
		log.info("Rent and PG is clicked");
			}

}
