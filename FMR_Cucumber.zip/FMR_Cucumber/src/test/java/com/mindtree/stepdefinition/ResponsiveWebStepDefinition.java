package com.mindtree.stepdefinition;

import java.util.concurrent.TimeUnit;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import com.mindtree.reusuablecomponents.HelperClass;
import com.mindtree.utility.ResponsiveWebUtility;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 * @author M1049109
 * Name:Swati Jha
 * Description:This class contains the step definition for Responsive Web Design
 * Date:31-12-2018
 */
public class ResponsiveWebStepDefinition {
	static WebDriver driver1;
	static Logger log=Logger.getLogger(ResponsiveWebStepDefinition.class);
	
	@Given("^I want to open the google chome browser$")
	public void i_want_to_open_the_google_chome_browser() throws Throwable {
		HelperClass.openBrowserAndNavigateToURL();
		 log.info("Browser is opened");
			}

	@When("^I open the FMR webpage$")
	public void i_open_the_FMR_webpage() throws Throwable {
	   
	}

	
	@Then("^I enter length (\\d+) and breadth (\\d+) of the window$")
	public void i_enter_length_and_breadth_of_the_window(int length, int breadth) throws Throwable {
	    ResponsiveWebUtility.responsiveWindow(HelperClass.driver, length, breadth);
	    HelperClass.driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
	    log.info("Responsive window is made");
		HelperClass.closeBrowser();

	}


}
