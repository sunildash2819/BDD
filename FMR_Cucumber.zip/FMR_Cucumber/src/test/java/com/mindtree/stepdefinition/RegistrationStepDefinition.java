package com.mindtree.stepdefinition;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.joda.time.Seconds;
import org.openqa.selenium.WebDriver;

import com.mindtree.pageobjects.RegistrationPageObject;
import com.mindtree.reusuablecomponents.HelperClass;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 * @author M1049109
 * Name:Swati Jha
 * Description: This class contains the step definition for registration of new user
 * Date:30-12-2018
 */
public class RegistrationStepDefinition {
	
	static Logger log=Logger.getLogger(RegistrationStepDefinition.class);
	@Given("^I open the browser and go to registration page$")
	public void i_open_the_browser_and_go_to_registration_page() throws Throwable {
		HelperClass.openBrowserAndNavigateToURL();
		 log.info("Browser is opened and navigated to URL");
		Thread.sleep(5000);
		
	}

	@When("^I click on register option and go to SignUp page$")
	public void i_click_on_register_option_and_go_to_SignUp_page() throws Throwable {
		RegistrationPageObject.newUserRegistration(HelperClass.driver);
		 log.info("Clicking on register option");
	}

	@Then("^I select user type$")
	public void i_select_user_type() throws Throwable {
		// RegistrationPageObject.newUserType(driver); 
	}

	@Then("^I will enter the firstName \"([^\"]*)\" and the lastName \"([^\"]*)\"$")
	public void i_will_enter_the_firstName_and_the_lastName(String firstName, String lastName) throws Throwable {
		 RegistrationPageObject.newUserName(HelperClass.driver, firstName, lastName);
		 log.info("Entering the firstname and lastname");
	}

	@Then("^I enter \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_enter_and_and(String email, String password, String confirmPassword) throws Throwable {
		 RegistrationPageObject.newUserEmailPassword(HelperClass.driver, email, password, confirmPassword); 
		 log.info("Entering emailid,password and new password");
	}

	@Then("^I enter \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_enter_and_and_and(String phoneNumber, String city, String street, String postalCode) throws Throwable {
		 RegistrationPageObject.newUserContact(HelperClass.driver, phoneNumber, city, street, postalCode);
		 log.info("New user contact is entered");
	}

	@Then("^I click on sign up$")
	public void i_click_on_sign_up() throws Throwable {
		RegistrationPageObject.completeRegistration(HelperClass.driver); 
		 HelperClass.closeBrowser();
	}


		}

