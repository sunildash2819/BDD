package com.mindtree.stepdefinition;

import org.apache.log4j.Logger;
import org.junit.Assert;
import com.mindtree.pageobjects.HomePageObject;
import com.mindtree.pageobjects.LoginPageObject;
import com.mindtree.reusuablecomponents.HelperClass;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
/**
 * 
 * @author M1049131
 * Name : Sunil Kumar Dash
 * Description: This class describes the test cases for Login scenario
 * Date:28-12-2018
 */
public class LoginTestStepDefinition {
	static Logger log=Logger.getLogger(LoginTestStepDefinition.class);
	static boolean check;
	/*Method for opening browser and navigating to homepage*/
	@Given("^I open the browser and navigate to home page$")
	public void i_open_the_browser_and_navigate_to_home_page() throws Throwable {
		HelperClass.openBrowserAndNavigateToURL();
		log.info("Browser is opened");
	    
	}
	
	/*Method to click on login button and navigate to login page*/
	@When("^I click on login button and go to login page$")
	public void i_click_on_login_button_and_go_to_login_page() throws Throwable {
		
	   check=HomePageObject.clickOnLogin();
	   Assert.assertTrue(check);
	   log.info("Login button is clicked");
	}
	
	/*Method to enter username and password in the correct fields*/
	@Then("^I enter \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_enter_and(String username, String password) throws Throwable {
		check=LoginPageObject.userNameField(username);
		Assert.assertTrue(check);
		check=LoginPageObject.passwordField(password);
		Assert.assertTrue(check);
	    log.info("Entering the username and password");
	}
	
	/*Method to click on sign in button*/
	@And("^I click on sign in button$")
	public void i_click_on_sign_in_button() throws Throwable {
		
		check=LoginPageObject.clickOnSignIn();
		Assert.assertTrue(check);
	    log.info("Entering the username and password");
	}
	
	/*Method to close the browser*/
	@And("^The browser should be closed$")
	public void the_browser_should_be_closed() throws Throwable {
		
		HelperClass.closeBrowser();
		 log.trace("Browser is closed");
	    
	}
	
	/*Method to click on forgot password option*/
	@Then("^I click on forgot password$")
	public void i_click_on_forgot_password() throws Throwable {
	 
		check=LoginPageObject.clickOnForgetPassword();
		Assert.assertTrue(check);
		log.info("Clicking on Forget Password");
	}
	
	/*Method to enter username in the correct field*/
	@Then("^I enter my \"([^\"]*)\"$")
	public void i_enter_my(String username) throws Throwable {	
		check=LoginPageObject.enterUsername(username);
		Assert.assertTrue(check);
	    log.trace("Entering username");
	}
	
	/*Method to click on submit button*/
	@And("^I click on submit button$")
	public void i_click_on_submit_button() throws Throwable {
		
	   check=LoginPageObject.clickOnSubmit();
	   Assert.assertTrue(check);
	   log.trace("Clicking on submit button");
	}
	
	/*Method to close the browser*/
	@And("^The application should be closed$")
	public void the_application_should_be_closed() throws Throwable {
		HelperClass.closeBrowser();
		 log.trace("Closing the browser");
	}
}
