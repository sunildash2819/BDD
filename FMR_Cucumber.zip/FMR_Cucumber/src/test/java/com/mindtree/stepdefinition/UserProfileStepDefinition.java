package com.mindtree.stepdefinition;

import org.apache.log4j.Logger;

import com.mindtree.pageobjects.RegistrationPageObject;
import com.mindtree.pageobjects.UserProfilePageObjects;
import com.mindtree.reusuablecomponents.HelperClass;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


/**
 * @author M1049200
 * Name:L M. Lavanya
 * Description: This class contains the step definition for user profile
 * Date:31-12-2018
 */
public class UserProfileStepDefinition {
	static Logger log=Logger.getLogger(UserProfileStepDefinition.class);
	
	
	@Given("^I open the browser and navigate to home page of website$")
	public void i_open_the_browser_and_navigate_to_home_page_of_website() throws Throwable {
		HelperClass.openBrowserAndNavigateToURL();
		 log.info("Browser is opened");

	}

	@When("^I click on login  and go to login page$")
	public void i_click_on_login_and_go_to_login_page() throws Throwable {

		UserProfilePageObjects.login_FMR();
		 log.debug("Login button is clicked");
	}

	@Then("^I enter the valid \"([^\"]*)\" and \"([^\"]*)\" and click on signin$")
	public void i_enter_the_valid_and_and_click_on_signin(String username, String password) throws Throwable {
		 UserProfilePageObjects.login(username, password);
		 log.info("Able to sign in");
	}

	@And("^I navigate to profile page$")
	public void i_navigate_to_profile_page() throws Throwable {
		UserProfilePageObjects.My_profile();
		 log.info("Profile page is displayed");

	}

	@When("^I click on change password$")
	public void i_click_on_change_password() throws Throwable {
		UserProfilePageObjects.Click_changepw();
		 log.info("Clicking on Change password");

	}

	@Then("^I enter the old password and new password and confirm password$")
	public void i_enter_the_old_password_and_new_password_and_confirm_password() throws Throwable {
		UserProfilePageObjects.Change_Password();
		 log.info("Change password is done");
	}

	@Then("^I click on submit$")
	public void i_click_on_submit() throws Throwable {
		UserProfilePageObjects.submit();
		 log.info("Submit button is clicked");
		HelperClass.closeBrowser();
	}

	@When("^I click on login button  and go to login page$")
	public void i_click_on_login_button_and_go_to_login_page() throws Throwable {
		
		UserProfilePageObjects.login_FMR();
		 log.info("Login button is clicked");
	}

	@When("^I click on edit profile$")
	public void i_click_on_edit_profile() throws Throwable {

		 UserProfilePageObjects.edit_Profile();
		 log.info("Clicking on edit profile");

	}

	@Then("^I see the edit profile page$")
	public void i_see_the_edit_profile_page() throws Throwable {
		
	}

	@When("^I click on booking history$")
	public void i_click_on_booking_history() throws Throwable {
		UserProfilePageObjects.Booking_history();
		 log.info("Clicking on booking history");

	}

	@Then("^I see the booking history page$")
	public void i_see_the_booking_history_page() throws Throwable {
		HelperClass.closeBrowser();
		 log.info("Browser is closed");

	}

}
