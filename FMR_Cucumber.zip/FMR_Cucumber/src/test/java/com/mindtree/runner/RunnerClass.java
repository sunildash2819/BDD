package com.mindtree.runner;

import java.io.File;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import com.cucumber.listener.Reporter;
import com.mindtree.utility.PropertyConfigUtility;
import com.mindtree.utility.SendMailUtility;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

/** 
 * @author M1049131
 * Name : Sunil Kumar Dash
 * Description: This class is used to start the execution of all the feature files 
 * 				and contains the methods that will execute before and after execution.
 * Date:28-12-2018
 */
@RunWith(Cucumber.class)
@CucumberOptions(features= {"features"},
glue="com.mindtree.stepdefinition",
tags= {"@all"},
plugin= {"com.cucumber.listener.ExtentCucumberFormatter:report\\FMR_TestReport.html",
		"pretty","html:Reports/cucumber","json:target/cucumber/cucumber.json"},
monochrome=true)
public class RunnerClass {
	
	/*Method to execute before start of the execution*/
	@BeforeClass
	public static void setUp() throws Exception
	{
		PropertyConfigUtility propertyConfig=new PropertyConfigUtility();
		propertyConfig.configProperty();
		
	}
	
	/*Method to execute after end of the execution*/
	@AfterClass
	public static  void writeExtentReport() throws Exception
	{
		Reporter.loadXMLConfig(new File(PropertyConfigUtility.prop.getProperty("extentReportConfigFilePath")));
		Reporter.setSystemInfo("System","Windows 10 64-bit");
		Reporter.setSystemInfo("JAVA Version ","1.8");
		Reporter.setSystemInfo("Maven Version","3.5.2");
		Reporter.setSystemInfo("Selenium Version","3.14");
		
		//SendMailUtility.sendMail();
	
	}
	
}
