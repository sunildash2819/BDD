package com.mindtree.pageobjects;

import com.mindtree.reusuablecomponents.HelperClass;
import com.mindtree.uistore.LoginButtonUI;
/** 
 * @author M1049131
 * Name : Sunil Kumar Dash
 * Description: This class contains the page objects for the home page. 
 * Date:28-12-2018
 */
public class HomePageObject {
	/*Method to click on login button*/
	public static boolean clickOnLogin()
	{
		try {
		HelperClass.driver.findElement(LoginButtonUI.loginButtonLocator).click();
		return true;
		}
		catch(Exception e)
		{
			return false;
		}
	}
}
