package com.mindtree.pageobjects;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.mindtree.uistore.RegistrationUI;

/**
 * @author M1049109
 * Name:Swati Jha
 * Description:This class contains the page objects of registration step definition
 * Date:30-12-2018
 */
public class RegistrationPageObject {
		static Logger log=Logger.getLogger(RegistrationPageObject.class);
	
	/*Method to enter into the registration page*/
	public static void newUserRegistration(WebDriver driver)
	{
		try {
		driver.findElement(RegistrationUI.loginButton).click();
		driver.findElement(RegistrationUI.register).click();
		}
		catch (Exception e) {
			log.error(e);
		}
	}
	
	
	/*Method to select the type of user that is customer of partner*/
	public static void newUserType(WebDriver driver)
	{
		//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		//driver.findElement(RegistrationUI.customerToggle).click();
	}
	
	/*Method to enter the firstname and lastname of the user*/
	public static void newUserName(WebDriver driver,String fName,String lName)
	{
		try {
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(RegistrationUI.firstName).sendKeys(fName);
		driver.findElement(RegistrationUI.firstName).clear();
		driver.findElement(RegistrationUI.firstName).sendKeys(fName);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(RegistrationUI.lastName).sendKeys(lName);	
		}
		catch(Exception e)
		{
			log.error(e);
		}
	}
	
	/*Method to enter the email-id, password and confirm password of the user*/
	public static void newUserEmailPassword(WebDriver driver,String email,String password, String confirmPassword)
	{
		try {
		driver.findElement(RegistrationUI.email).sendKeys(email);
		driver.findElement(RegistrationUI.password).sendKeys(password);
		driver.findElement(RegistrationUI.confirmPassword).sendKeys(confirmPassword);
		}
		catch(Exception e)
		{
			log.error(e);
		}
	}
	
	/*Method to enter the phone and address of the user*/
	public static void newUserContact(WebDriver driver,String phone,String city,String street,String pincode)
	{
		try {
		driver.findElement(RegistrationUI.phone).sendKeys(phone);
		driver.findElement(RegistrationUI.userCity).sendKeys(city);
		driver.findElement(RegistrationUI.userStreet).sendKeys(street);
		driver.findElement(RegistrationUI.userPostalCode).sendKeys(pincode);
		}
		catch (Exception e) {
			log.error(e);
		}
	
	}
	
	/*Method to submit the registration*/
	public static void completeRegistration(WebDriver driver)
	{
		try
		{
		driver.findElement(RegistrationUI.signUpButton).click();
		try
		{
			WebDriverWait wait = new WebDriverWait(driver,20);
			wait.until(ExpectedConditions.visibilityOfElementLocated(RegistrationUI.alreadyRegistered));
		if(driver.findElement(RegistrationUI.alreadyRegistered).getText().equalsIgnoreCase("Already Registered"))
			log.info("Sorry!! Already Registered");
		}
		catch(Exception e)
		{
			log.info("Congratulations!! Successfully Registered");
		}
		}
		catch (Exception e) {
			log.info("Fill all madatory fields correctly!!");
		}
		
		
	}
	

}
