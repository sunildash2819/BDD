package com.mindtree.pageobjects;

/**
 * @author M1049190
 * Name : Neeraja Chidambaram
 * Description : This class describes the test cases for Flat search
 * Date : 31/12/2018 
 */
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import com.mindtree.uistore.Homepageui;

public class SearchPageObject {
	static Logger log = Logger.getLogger(SearchPageObject.class);

	/* Method for Flat Buy(positive flow) */
	/* Method for selecting city */
	public static WebDriver selectCity(WebDriver driver) throws IOException {
		try {
			Select dropdown = new Select(driver.findElement(Homepageui.selectcity));
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			dropdown.selectByIndex(1);
			return driver;
		} catch (Exception e) {
			log.error(e);
		}
		return driver;
	}

	/* Method for entering the location */
	public static WebDriver enterLocation(WebDriver driver, String location) throws IOException {

		try {
			driver.findElement(Homepageui.location).sendKeys(location);
			return driver;
		} catch (Exception e) {
			log.error(e);
		}
		return driver;

	}

	/* Method to click buy and to click flat */
	public static WebDriver clickBuyandFlat(WebDriver driver) throws IOException {
		try
		{
		driver.findElement(Homepageui.buy).click();
		driver.findElement(Homepageui.flat).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		return driver;
		}catch(Exception e)
		{
			log.error(e);
		}
		return driver;
	}

	/* Method to click submit button */
	public static WebDriver clickSearch(WebDriver driver) throws IOException {
		try
		{
		driver.findElement(Homepageui.button).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		// driver.findElement(Homepageui.more).click();
		return driver;
		}catch(Exception e)
		{
			log.error(e);
		}
		return driver;
	}

}
