package com.mindtree.uistore;

import org.openqa.selenium.By;

public class LoginButtonUI {

	public static By loginButtonLocator=By.xpath("//a[@href='#/login']");
}
