package com.mindtree.uistore;

import org.openqa.selenium.By;
/**
 * @author M1049131
 * Name: Sunil Kumar Dash
 * Description: This class contains the locators of various web elements for login page objects.
 * Date: 31-12-2018
 *
 */
public class LoginPageUI {

	public static By userNameFieldLocator=By.id("loginformEmail");
	public static By passwordFieldLocator=By.id("loginformPassword");
	public static By forgetPasswordLocator=By.xpath("//a[contains(text(),'Forgot password?')]");
	public static By signInButtonLocator=By.xpath("//button[contains(text(),'Sign in')]");
	public static By forgotPasswordusername=By.xpath("//input[@localid='uEmailId']");
	public static By forgotPasswordSubmit=By.xpath("//button[contains(text(),'Submit')]");
}
