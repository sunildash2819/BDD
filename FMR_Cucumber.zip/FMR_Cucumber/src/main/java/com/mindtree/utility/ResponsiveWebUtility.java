package com.mindtree.utility;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;

/**
 * @author M1049109
 * Name:Swati Jha
 * Description: This class contains the utility of responsive web design
 * Date:29-12-2018
 *
 */
public class ResponsiveWebUtility {
	/*Method to take the input and set the dimensionof the window*/
	public static void  responsiveWindow(WebDriver driver,int length,int breadth)
	{
		Dimension dimension = new Dimension(length, breadth);
		driver.manage().window().setSize(dimension);
		
	}

}
