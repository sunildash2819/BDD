$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("LoginScenario.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: your.email@your.domain.com"
    },
    {
      "line": 2,
      "value": "#Keywords Summary :"
    },
    {
      "line": 3,
      "value": "#Feature: List of scenarios."
    },
    {
      "line": 4,
      "value": "#Scenario: Business rule through list of steps with arguments."
    },
    {
      "line": 5,
      "value": "#Given: Some precondition step"
    },
    {
      "line": 6,
      "value": "#When: Some key actions"
    },
    {
      "line": 7,
      "value": "#Then: To observe outcomes or validation"
    },
    {
      "line": 8,
      "value": "#And,But: To enumerate more Given,When,Then steps"
    },
    {
      "line": 9,
      "value": "#Scenario Outline: List of steps for data-driven as an Examples and \u003cplaceholder\u003e"
    },
    {
      "line": 10,
      "value": "#Examples: Container for s table"
    },
    {
      "line": 11,
      "value": "#Background: List of steps run before each of the scenarios"
    },
    {
      "line": 12,
      "value": "#\"\"\" (Doc Strings)"
    },
    {
      "line": 13,
      "value": "#| (Data Tables)"
    },
    {
      "line": 14,
      "value": "#@ (Tags/Labels):To group Scenarios"
    },
    {
      "line": 15,
      "value": "#\u003c\u003e (placeholder)"
    },
    {
      "line": 16,
      "value": "#\"\""
    },
    {
      "line": 17,
      "value": "## (Comments)"
    },
    {
      "line": 18,
      "value": "#Sample Feature Definition Template"
    }
  ],
  "line": 20,
  "name": "Login Feature",
  "description": "",
  "id": "login-feature",
  "keyword": "Feature",
  "tags": [
    {
      "line": 19,
      "name": "@Login"
    },
    {
      "line": 19,
      "name": "@all"
    }
  ]
});
formatter.scenarioOutline({
  "line": 23,
  "name": "Login Test",
  "description": "",
  "id": "login-feature;login-test",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 22,
      "name": "@LoginTestScenario"
    }
  ]
});
formatter.step({
  "line": 24,
  "name": "I open the browser and navigate to home page",
  "keyword": "Given "
});
formatter.step({
  "line": 25,
  "name": "I click on login button and go to login page",
  "keyword": "When "
});
formatter.step({
  "line": 26,
  "name": "I enter \"\u003cusername\u003e\" and \"\u003cpassword\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "line": 27,
  "name": "I click on sign in button",
  "keyword": "And "
});
formatter.step({
  "line": 28,
  "name": "The browser should be closed",
  "keyword": "And "
});
formatter.examples({
  "line": 30,
  "name": "",
  "description": "",
  "id": "login-feature;login-test;",
  "rows": [
    {
      "cells": [
        "username",
        "password"
      ],
      "line": 31,
      "id": "login-feature;login-test;;1"
    },
    {
      "cells": [
        "sunildash1908@yahoo.com",
        "Sunilk@12"
      ],
      "line": 32,
      "id": "login-feature;login-test;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 4830998,
  "status": "passed"
});
formatter.scenario({
  "line": 32,
  "name": "Login Test",
  "description": "",
  "id": "login-feature;login-test;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 19,
      "name": "@Login"
    },
    {
      "line": 22,
      "name": "@LoginTestScenario"
    },
    {
      "line": 19,
      "name": "@all"
    }
  ]
});
formatter.step({
  "line": 24,
  "name": "I open the browser and navigate to home page",
  "keyword": "Given "
});
formatter.step({
  "line": 25,
  "name": "I click on login button and go to login page",
  "keyword": "When "
});
formatter.step({
  "line": 26,
  "name": "I enter \"sunildash1908@yahoo.com\" and \"Sunilk@12\"",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 27,
  "name": "I click on sign in button",
  "keyword": "And "
});
formatter.step({
  "line": 28,
  "name": "The browser should be closed",
  "keyword": "And "
});
formatter.match({
  "location": "LoginTestStepDefinition.i_open_the_browser_and_navigate_to_home_page()"
});
formatter.result({
  "duration": 5638176941,
  "status": "passed"
});
formatter.match({
  "location": "LoginTestStepDefinition.i_click_on_login_button_and_go_to_login_page()"
});
formatter.result({
  "duration": 50125838043,
  "error_message": "java.lang.AssertionError\r\n\tat org.junit.Assert.fail(Assert.java:86)\r\n\tat org.junit.Assert.assertTrue(Assert.java:41)\r\n\tat org.junit.Assert.assertTrue(Assert.java:52)\r\n\tat com.mindtree.stepdefinition.LoginTestStepDefinition.i_click_on_login_button_and_go_to_login_page(LoginTestStepDefinition.java:35)\r\n\tat ✽.When I click on login button and go to login page(LoginScenario.feature:25)\r\n",
  "status": "failed"
});
formatter.match({
  "arguments": [
    {
      "val": "sunildash1908@yahoo.com",
      "offset": 9
    },
    {
      "val": "Sunilk@12",
      "offset": 39
    }
  ],
  "location": "LoginTestStepDefinition.i_enter_and(String,String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "LoginTestStepDefinition.i_click_on_sign_in_button()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "LoginTestStepDefinition.the_browser_should_be_closed()"
});
formatter.result({
  "status": "skipped"
});
formatter.after({
  "duration": 1009565853,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 36,
  "name": "Forget Password Test",
  "description": "",
  "id": "login-feature;forget-password-test",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 35,
      "name": "@ForgotPasswordTestScenario"
    }
  ]
});
formatter.step({
  "line": 37,
  "name": "I open the browser and navigate to home page",
  "keyword": "Given "
});
formatter.step({
  "line": 38,
  "name": "I click on login button and go to login page",
  "keyword": "When "
});
formatter.step({
  "line": 39,
  "name": "I click on forgot password",
  "keyword": "Then "
});
formatter.step({
  "line": 40,
  "name": "I enter my \"\u003cusername2\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "line": 41,
  "name": "I click on submit button",
  "keyword": "And "
});
formatter.step({
  "line": 42,
  "name": "The application should be closed",
  "keyword": "And "
});
formatter.examples({
  "line": 44,
  "name": "",
  "description": "",
  "id": "login-feature;forget-password-test;",
  "rows": [
    {
      "cells": [
        "username2"
      ],
      "line": 45,
      "id": "login-feature;forget-password-test;;1"
    },
    {
      "cells": [
        "bishal@mindtree.in"
      ],
      "line": 46,
      "id": "login-feature;forget-password-test;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 3154484,
  "status": "passed"
});
formatter.scenario({
  "line": 46,
  "name": "Forget Password Test",
  "description": "",
  "id": "login-feature;forget-password-test;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 19,
      "name": "@Login"
    },
    {
      "line": 35,
      "name": "@ForgotPasswordTestScenario"
    },
    {
      "line": 19,
      "name": "@all"
    }
  ]
});
formatter.step({
  "line": 37,
  "name": "I open the browser and navigate to home page",
  "keyword": "Given "
});
formatter.step({
  "line": 38,
  "name": "I click on login button and go to login page",
  "keyword": "When "
});
formatter.step({
  "line": 39,
  "name": "I click on forgot password",
  "keyword": "Then "
});
formatter.step({
  "line": 40,
  "name": "I enter my \"bishal@mindtree.in\"",
  "matchedColumns": [
    0
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 41,
  "name": "I click on submit button",
  "keyword": "And "
});
formatter.step({
  "line": 42,
  "name": "The application should be closed",
  "keyword": "And "
});
formatter.match({
  "location": "LoginTestStepDefinition.i_open_the_browser_and_navigate_to_home_page()"
});
formatter.result({
  "duration": 25388862309,
  "status": "passed"
});
formatter.match({
  "location": "LoginTestStepDefinition.i_click_on_login_button_and_go_to_login_page()"
});
formatter.result({
  "duration": 50037241689,
  "error_message": "java.lang.AssertionError\r\n\tat org.junit.Assert.fail(Assert.java:86)\r\n\tat org.junit.Assert.assertTrue(Assert.java:41)\r\n\tat org.junit.Assert.assertTrue(Assert.java:52)\r\n\tat com.mindtree.stepdefinition.LoginTestStepDefinition.i_click_on_login_button_and_go_to_login_page(LoginTestStepDefinition.java:35)\r\n\tat ✽.When I click on login button and go to login page(LoginScenario.feature:38)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "LoginTestStepDefinition.i_click_on_forgot_password()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "bishal@mindtree.in",
      "offset": 12
    }
  ],
  "location": "LoginTestStepDefinition.i_enter_my(String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "LoginTestStepDefinition.i_click_on_submit_button()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "LoginTestStepDefinition.the_application_should_be_closed()"
});
formatter.result({
  "status": "skipped"
});
formatter.after({
  "duration": 594423190,
  "status": "passed"
});
formatter.uri("RWD.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: your.email@your.domain.com"
    },
    {
      "line": 2,
      "value": "#Keywords Summary :"
    },
    {
      "line": 3,
      "value": "#Feature: List of scenarios."
    },
    {
      "line": 4,
      "value": "#Scenario: Business rule through list of steps with arguments."
    },
    {
      "line": 5,
      "value": "#Given: Some precondition step"
    },
    {
      "line": 6,
      "value": "#When: Some key actions"
    },
    {
      "line": 7,
      "value": "#Then: To observe outcomes or validation"
    },
    {
      "line": 8,
      "value": "#And,But: To enumerate more Given,When,Then steps"
    },
    {
      "line": 9,
      "value": "#Scenario Outline: List of steps for data-driven as an Examples and \u003cplaceholder\u003e"
    },
    {
      "line": 10,
      "value": "#Examples: Container for s table"
    },
    {
      "line": 11,
      "value": "#Background: List of steps run before each of the scenarios"
    },
    {
      "line": 12,
      "value": "#\"\"\" (Doc Strings)"
    },
    {
      "line": 13,
      "value": "#| (Data Tables)"
    },
    {
      "line": 14,
      "value": "#@ (Tags/Labels):To group Scenarios"
    },
    {
      "line": 15,
      "value": "#\u003c\u003e (placeholder)"
    },
    {
      "line": 16,
      "value": "#\"\""
    },
    {
      "line": 17,
      "value": "## (Comments)"
    },
    {
      "line": 18,
      "value": "#Sample Feature Definition Template"
    }
  ],
  "line": 20,
  "name": "Responsive Web Design Feature",
  "description": "",
  "id": "responsive-web-design-feature",
  "keyword": "Feature",
  "tags": [
    {
      "line": 19,
      "name": "@RWD"
    },
    {
      "line": 19,
      "name": "@all"
    }
  ]
});
formatter.scenarioOutline({
  "line": 24,
  "name": "Responsive Web Check",
  "description": "",
  "id": "responsive-web-design-feature;responsive-web-check",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 23,
      "name": "@rwd"
    }
  ]
});
formatter.step({
  "line": 25,
  "name": "I want to open the google chome browser",
  "keyword": "Given "
});
formatter.step({
  "line": 26,
  "name": "I open the FMR webpage",
  "keyword": "When "
});
formatter.step({
  "line": 27,
  "name": "I enter length \u003clength\u003e and breadth \u003cbreadth\u003e of the window",
  "keyword": "Then "
});
formatter.examples({
  "line": 31,
  "name": "",
  "description": "",
  "id": "responsive-web-design-feature;responsive-web-check;",
  "rows": [
    {
      "cells": [
        "length",
        "breadth"
      ],
      "line": 32,
      "id": "responsive-web-design-feature;responsive-web-check;;1"
    },
    {
      "cells": [
        "250",
        "500"
      ],
      "line": 33,
      "id": "responsive-web-design-feature;responsive-web-check;;2"
    },
    {
      "cells": [
        "500",
        "250"
      ],
      "line": 34,
      "id": "responsive-web-design-feature;responsive-web-check;;3"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 762310,
  "status": "passed"
});
formatter.scenario({
  "line": 33,
  "name": "Responsive Web Check",
  "description": "",
  "id": "responsive-web-design-feature;responsive-web-check;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 19,
      "name": "@RWD"
    },
    {
      "line": 23,
      "name": "@rwd"
    },
    {
      "line": 19,
      "name": "@all"
    }
  ]
});
formatter.step({
  "line": 25,
  "name": "I want to open the google chome browser",
  "keyword": "Given "
});
formatter.step({
  "line": 26,
  "name": "I open the FMR webpage",
  "keyword": "When "
});
formatter.step({
  "line": 27,
  "name": "I enter length 250 and breadth 500 of the window",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "ResponsiveWebStepDefinition.i_want_to_open_the_google_chome_browser()"
});
formatter.result({
  "duration": 4120443847,
  "status": "passed"
});
formatter.match({
  "location": "ResponsiveWebStepDefinition.i_open_the_FMR_webpage()"
});
formatter.result({
  "duration": 17067,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "250",
      "offset": 15
    },
    {
      "val": "500",
      "offset": 31
    }
  ],
  "location": "ResponsiveWebStepDefinition.i_enter_length_and_breadth_of_the_window(int,int)"
});
formatter.result({
  "duration": 1075003342,
  "status": "passed"
});
formatter.after({
  "duration": 9448093,
  "status": "passed"
});
formatter.before({
  "duration": 1924548,
  "status": "passed"
});
formatter.scenario({
  "line": 34,
  "name": "Responsive Web Check",
  "description": "",
  "id": "responsive-web-design-feature;responsive-web-check;;3",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 19,
      "name": "@RWD"
    },
    {
      "line": 23,
      "name": "@rwd"
    },
    {
      "line": 19,
      "name": "@all"
    }
  ]
});
formatter.step({
  "line": 25,
  "name": "I want to open the google chome browser",
  "keyword": "Given "
});
formatter.step({
  "line": 26,
  "name": "I open the FMR webpage",
  "keyword": "When "
});
formatter.step({
  "line": 27,
  "name": "I enter length 500 and breadth 250 of the window",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "ResponsiveWebStepDefinition.i_want_to_open_the_google_chome_browser()"
});
formatter.result({
  "duration": 4137081547,
  "status": "passed"
});
formatter.match({
  "location": "ResponsiveWebStepDefinition.i_open_the_FMR_webpage()"
});
formatter.result({
  "duration": 19343,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "500",
      "offset": 15
    },
    {
      "val": "250",
      "offset": 31
    }
  ],
  "location": "ResponsiveWebStepDefinition.i_enter_length_and_breadth_of_the_window(int,int)"
});
formatter.result({
  "duration": 1002423463,
  "status": "passed"
});
formatter.after({
  "duration": 10151808,
  "status": "passed"
});
formatter.uri("Search.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: your.email@your.domain.com"
    },
    {
      "line": 2,
      "value": "#Keywords Summary :"
    },
    {
      "line": 3,
      "value": "#Feature: List of scenarios."
    },
    {
      "line": 4,
      "value": "#Scenario: Business rule through list of steps with arguments."
    },
    {
      "line": 5,
      "value": "#Given: Some precondition step"
    },
    {
      "line": 6,
      "value": "#When: Some key actions"
    },
    {
      "line": 7,
      "value": "#Then: To observe outcomes or validation"
    },
    {
      "line": 8,
      "value": "#And,But: To enumerate more Given,When,Then steps"
    },
    {
      "line": 9,
      "value": "#Scenario Outline: List of steps for data-driven as an Examples and \u003cplaceholder\u003e"
    },
    {
      "line": 10,
      "value": "#Examples: Container for s table"
    },
    {
      "line": 11,
      "value": "#Background: List of steps run before each of the scenarios"
    },
    {
      "line": 12,
      "value": "#\"\"\" (Doc Strings)"
    },
    {
      "line": 13,
      "value": "#| (Data Tables)"
    },
    {
      "line": 14,
      "value": "#@ (Tags/Labels):To group Scenarios"
    },
    {
      "line": 15,
      "value": "#\u003c\u003e (placeholder)"
    },
    {
      "line": 16,
      "value": "#\"\""
    },
    {
      "line": 17,
      "value": "## (Comments)"
    },
    {
      "line": 18,
      "value": "#Sample Feature Definition Template"
    }
  ],
  "line": 20,
  "name": "Searching Feature",
  "description": "",
  "id": "searching-feature",
  "keyword": "Feature",
  "tags": [
    {
      "line": 19,
      "name": "@Search"
    },
    {
      "line": 19,
      "name": "@all"
    }
  ]
});
formatter.scenarioOutline({
  "line": 23,
  "name": "search for flat test",
  "description": "",
  "id": "searching-feature;search-for-flat-test",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 22,
      "name": "@FlatSearchScenario"
    }
  ]
});
formatter.step({
  "line": 24,
  "name": "I open the browser chrome and navigate to homepage",
  "keyword": "Given "
});
formatter.step({
  "line": 25,
  "name": "I select city",
  "keyword": "When "
});
formatter.step({
  "line": 26,
  "name": "I enter the \"\u003clocation\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "line": 27,
  "name": "I click on Buy and I click on Flat",
  "keyword": "And "
});
formatter.step({
  "line": 28,
  "name": "I click on search button",
  "keyword": "And "
});
formatter.examples({
  "line": 30,
  "name": "",
  "description": "",
  "id": "searching-feature;search-for-flat-test;",
  "rows": [
    {
      "cells": [
        "location"
      ],
      "line": 31,
      "id": "searching-feature;search-for-flat-test;;1"
    },
    {
      "cells": [
        "ayanavaram"
      ],
      "line": 32,
      "id": "searching-feature;search-for-flat-test;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 3253471,
  "status": "passed"
});
formatter.scenario({
  "line": 32,
  "name": "search for flat test",
  "description": "",
  "id": "searching-feature;search-for-flat-test;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 19,
      "name": "@Search"
    },
    {
      "line": 22,
      "name": "@FlatSearchScenario"
    },
    {
      "line": 19,
      "name": "@all"
    }
  ]
});
formatter.step({
  "line": 24,
  "name": "I open the browser chrome and navigate to homepage",
  "keyword": "Given "
});
formatter.step({
  "line": 25,
  "name": "I select city",
  "keyword": "When "
});
formatter.step({
  "line": 26,
  "name": "I enter the \"ayanavaram\"",
  "matchedColumns": [
    0
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 27,
  "name": "I click on Buy and I click on Flat",
  "keyword": "And "
});
formatter.step({
  "line": 28,
  "name": "I click on search button",
  "keyword": "And "
});
formatter.match({
  "location": "SearchStepDefinition.i_open_the_browser_chrome_and_navigate_to_homepage()"
});
formatter.result({
  "duration": 4068811565,
  "status": "passed"
});
formatter.match({
  "location": "SearchStepDefinition.i_select_city()"
});
formatter.result({
  "duration": 50066934802,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "ayanavaram",
      "offset": 13
    }
  ],
  "location": "SearchStepDefinition.i_enter_the(String)"
});
formatter.result({
  "duration": 50029075870,
  "status": "passed"
});
formatter.match({
  "location": "SearchStepDefinition.i_click_on_Buy_and_I_click_on_Flat()"
});
formatter.result({
  "duration": 50032171190,
  "status": "passed"
});
formatter.match({
  "location": "SearchStepDefinition.i_click_on_search_button()"
});
formatter.result({
  "duration": 13249895467,
  "status": "passed"
});
formatter.after({
  "duration": 8283579,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 36,
  "name": "search for pg test",
  "description": "",
  "id": "searching-feature;search-for-pg-test",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 35,
      "name": "@PgSearchScenario"
    }
  ]
});
formatter.step({
  "line": 37,
  "name": "I open the browser chrome and navigate to homepage",
  "keyword": "Given "
});
formatter.step({
  "line": 38,
  "name": "I select city",
  "keyword": "When "
});
formatter.step({
  "line": 39,
  "name": "I enter the \"\u003clocation2\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "line": 40,
  "name": "I click on Rent and I click on pg",
  "keyword": "And "
});
formatter.step({
  "line": 41,
  "name": "I click on search button",
  "keyword": "And "
});
formatter.examples({
  "line": 43,
  "name": "",
  "description": "",
  "id": "searching-feature;search-for-pg-test;",
  "rows": [
    {
      "cells": [
        "location2"
      ],
      "line": 44,
      "id": "searching-feature;search-for-pg-test;;1"
    },
    {
      "cells": [
        "Annanagar"
      ],
      "line": 45,
      "id": "searching-feature;search-for-pg-test;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 1848318,
  "status": "passed"
});
formatter.scenario({
  "line": 45,
  "name": "search for pg test",
  "description": "",
  "id": "searching-feature;search-for-pg-test;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 19,
      "name": "@Search"
    },
    {
      "line": 35,
      "name": "@PgSearchScenario"
    },
    {
      "line": 19,
      "name": "@all"
    }
  ]
});
formatter.step({
  "line": 37,
  "name": "I open the browser chrome and navigate to homepage",
  "keyword": "Given "
});
formatter.step({
  "line": 38,
  "name": "I select city",
  "keyword": "When "
});
formatter.step({
  "line": 39,
  "name": "I enter the \"Annanagar\"",
  "matchedColumns": [
    0
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 40,
  "name": "I click on Rent and I click on pg",
  "keyword": "And "
});
formatter.step({
  "line": 41,
  "name": "I click on search button",
  "keyword": "And "
});
formatter.match({
  "location": "SearchStepDefinition.i_open_the_browser_chrome_and_navigate_to_homepage()"
});
formatter.result({
  "duration": 4405664987,
  "status": "passed"
});
formatter.match({
  "location": "SearchStepDefinition.i_select_city()"
});
formatter.result({
  "duration": 34052542503,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Annanagar",
      "offset": 13
    }
  ],
  "location": "SearchStepDefinition.i_enter_the(String)"
});
formatter.result({
  "duration": 22713426,
  "status": "passed"
});
formatter.match({
  "location": "SearchStepDefinition.i_click_on_Rent_and_I_click_on_pg()"
});
formatter.result({
  "duration": 12605422,
  "status": "passed"
});
formatter.match({
  "location": "SearchStepDefinition.i_click_on_search_button()"
});
formatter.result({
  "duration": 674725725,
  "status": "passed"
});
formatter.after({
  "duration": 9903204,
  "status": "passed"
});
formatter.uri("SignUp.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: your.email@your.domain.com"
    },
    {
      "line": 2,
      "value": "#Keywords Summary :"
    },
    {
      "line": 3,
      "value": "#Feature: List of scenarios."
    },
    {
      "line": 4,
      "value": "#Scenario: Business rule through list of steps with arguments."
    },
    {
      "line": 5,
      "value": "#Given: Some precondition step"
    },
    {
      "line": 6,
      "value": "#When: Some key actions"
    },
    {
      "line": 7,
      "value": "#Then: To observe outcomes or validation"
    },
    {
      "line": 8,
      "value": "#And,But: To enumerate more Given,When,Then steps"
    },
    {
      "line": 9,
      "value": "#Scenario Outline: List of steps for data-driven as an Examples and \u003cplaceholder\u003e"
    },
    {
      "line": 10,
      "value": "#Examples: Container for s table"
    },
    {
      "line": 11,
      "value": "#Background: List of steps run before each of the scenarios"
    },
    {
      "line": 12,
      "value": "#\"\"\" (Doc Strings)"
    },
    {
      "line": 13,
      "value": "#| (Data Tables)"
    },
    {
      "line": 14,
      "value": "#@ (Tags/Labels):To group Scenarios"
    },
    {
      "line": 15,
      "value": "#\u003c\u003e (placeholder)"
    },
    {
      "line": 16,
      "value": "#\"\""
    },
    {
      "line": 17,
      "value": "## (Comments)"
    },
    {
      "line": 18,
      "value": "#Sample Feature Definition Template"
    }
  ],
  "line": 20,
  "name": "Sign Up Feature",
  "description": "",
  "id": "sign-up-feature",
  "keyword": "Feature",
  "tags": [
    {
      "line": 19,
      "name": "@Signup"
    },
    {
      "line": 19,
      "name": "@all"
    }
  ]
});
formatter.scenarioOutline({
  "line": 23,
  "name": "Sign Up FindMyRoom",
  "description": "",
  "id": "sign-up-feature;sign-up-findmyroom",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 22,
      "name": "@SignUpScenario"
    }
  ]
});
formatter.step({
  "line": 24,
  "name": "I open the browser and go to registration page",
  "keyword": "Given "
});
formatter.step({
  "line": 25,
  "name": "I click on register option and go to SignUp page",
  "keyword": "When "
});
formatter.step({
  "line": 26,
  "name": "I select user type",
  "keyword": "Then "
});
formatter.step({
  "line": 27,
  "name": "I will enter the firstName \"\u003cfirstName\u003e\" and the lastName \"\u003clastName\u003e\"",
  "keyword": "And "
});
formatter.step({
  "line": 28,
  "name": "I enter \"\u003cemail\u003e\" and \"\u003cpassword\u003e\" and \"\u003cconfirmPassword\u003e\"",
  "keyword": "And "
});
formatter.step({
  "line": 29,
  "name": "I enter \"\u003cphoneNumber\u003e\" and \"\u003ccity\u003e\" and \"\u003cstreet\u003e\" and \"\u003cpostalCode\u003e\"",
  "keyword": "And "
});
formatter.step({
  "line": 30,
  "name": "I click on sign up",
  "keyword": "And "
});
formatter.examples({
  "line": 32,
  "name": "",
  "description": "",
  "id": "sign-up-feature;sign-up-findmyroom;",
  "rows": [
    {
      "cells": [
        "firstName",
        "lastName",
        "email",
        "password",
        "confirmPassword",
        "phoneNumber",
        "city",
        "street",
        "postalCode"
      ],
      "line": 33,
      "id": "sign-up-feature;sign-up-findmyroom;;1"
    },
    {
      "cells": [
        "Anshuman",
        "Raj",
        "anshuman@gmail.com",
        "Anshuman@12",
        "Anshuman@12",
        "9090898908",
        "Delhi",
        "Sarojini Nagar",
        "110034"
      ],
      "line": 34,
      "id": "sign-up-feature;sign-up-findmyroom;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 2175996,
  "status": "passed"
});
formatter.scenario({
  "line": 34,
  "name": "Sign Up FindMyRoom",
  "description": "",
  "id": "sign-up-feature;sign-up-findmyroom;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 19,
      "name": "@Signup"
    },
    {
      "line": 22,
      "name": "@SignUpScenario"
    },
    {
      "line": 19,
      "name": "@all"
    }
  ]
});
formatter.step({
  "line": 24,
  "name": "I open the browser and go to registration page",
  "keyword": "Given "
});
formatter.step({
  "line": 25,
  "name": "I click on register option and go to SignUp page",
  "keyword": "When "
});
formatter.step({
  "line": 26,
  "name": "I select user type",
  "keyword": "Then "
});
formatter.step({
  "line": 27,
  "name": "I will enter the firstName \"Anshuman\" and the lastName \"Raj\"",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 28,
  "name": "I enter \"anshuman@gmail.com\" and \"Anshuman@12\" and \"Anshuman@12\"",
  "matchedColumns": [
    2,
    3,
    4
  ],
  "keyword": "And "
});
formatter.step({
  "line": 29,
  "name": "I enter \"9090898908\" and \"Delhi\" and \"Sarojini Nagar\" and \"110034\"",
  "matchedColumns": [
    5,
    6,
    7,
    8
  ],
  "keyword": "And "
});
formatter.step({
  "line": 30,
  "name": "I click on sign up",
  "keyword": "And "
});
formatter.match({
  "location": "RegistrationStepDefinition.i_open_the_browser_and_go_to_registration_page()"
});
formatter.result({
  "duration": 9123879931,
  "status": "passed"
});
formatter.match({
  "location": "RegistrationStepDefinition.i_click_on_register_option_and_go_to_SignUp_page()"
});
formatter.result({
  "duration": 6154645398,
  "status": "passed"
});
formatter.match({
  "location": "RegistrationStepDefinition.i_select_user_type()"
});
formatter.result({
  "duration": 48356,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Anshuman",
      "offset": 28
    },
    {
      "val": "Raj",
      "offset": 56
    }
  ],
  "location": "RegistrationStepDefinition.i_will_enter_the_firstName_and_the_lastName(String,String)"
});
formatter.result({
  "duration": 6140989239,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "anshuman@gmail.com",
      "offset": 9
    },
    {
      "val": "Anshuman@12",
      "offset": 34
    },
    {
      "val": "Anshuman@12",
      "offset": 52
    }
  ],
  "location": "RegistrationStepDefinition.i_enter_and_and(String,String,String)"
});
formatter.result({
  "duration": 6091108564,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "9090898908",
      "offset": 9
    },
    {
      "val": "Delhi",
      "offset": 26
    },
    {
      "val": "Sarojini Nagar",
      "offset": 38
    },
    {
      "val": "110034",
      "offset": 59
    }
  ],
  "location": "RegistrationStepDefinition.i_enter_and_and_and(String,String,String,String)"
});
formatter.result({
  "duration": 6142183904,
  "status": "passed"
});
formatter.match({
  "location": "RegistrationStepDefinition.i_click_on_sign_up()"
});
formatter.result({
  "duration": 6931803403,
  "status": "passed"
});
formatter.after({
  "duration": 5387939,
  "status": "passed"
});
formatter.uri("Userprofile.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: your.email@your.domain.com"
    },
    {
      "line": 2,
      "value": "#Keywords Summary :"
    },
    {
      "line": 3,
      "value": "#Feature: List of scenarios."
    },
    {
      "line": 4,
      "value": "#Scenario: Business rule through list of steps with arguments."
    },
    {
      "line": 5,
      "value": "#Given: Some precondition step"
    },
    {
      "line": 6,
      "value": "#When: Some key actions"
    },
    {
      "line": 7,
      "value": "#Then: To observe outcomes or validation"
    },
    {
      "line": 8,
      "value": "#And,But: To enumerate more Given,When,Then steps"
    },
    {
      "line": 9,
      "value": "#Scenario Outline: List of steps for data-driven as an Examples and \u003cplaceholder\u003e"
    },
    {
      "line": 10,
      "value": "#Examples: Container for s table"
    },
    {
      "line": 11,
      "value": "#Background: List of steps run before each of the scenarios"
    },
    {
      "line": 12,
      "value": "#\"\"\" (Doc Strings)"
    },
    {
      "line": 13,
      "value": "#| (Data Tables)"
    },
    {
      "line": 14,
      "value": "#@ (Tags/Labels):To group Scenarios"
    },
    {
      "line": 15,
      "value": "#\u003c\u003e (placeholder)"
    },
    {
      "line": 16,
      "value": "#\"\""
    },
    {
      "line": 17,
      "value": "## (Comments)"
    },
    {
      "line": 18,
      "value": "#Sample Feature Definition Template"
    }
  ],
  "line": 20,
  "name": "UserDashboard Feature",
  "description": "",
  "id": "userdashboard-feature",
  "keyword": "Feature",
  "tags": [
    {
      "line": 19,
      "name": "@Userprofile"
    },
    {
      "line": 19,
      "name": "@all"
    }
  ]
});
formatter.scenarioOutline({
  "line": 23,
  "name": "Update the user profile",
  "description": "",
  "id": "userdashboard-feature;update-the-user-profile",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 22,
      "name": "@changePasswordScenario"
    }
  ]
});
formatter.step({
  "line": 24,
  "name": "I open the browser and navigate to home page of website",
  "keyword": "Given "
});
formatter.step({
  "line": 25,
  "name": "I click on login  and go to login page",
  "keyword": "When "
});
formatter.step({
  "line": 26,
  "name": "I enter the valid \"\u003cusername\u003e\" and \"\u003cpassword\u003e\" and click on signin",
  "keyword": "Then "
});
formatter.step({
  "line": 27,
  "name": "I navigate to profile page",
  "keyword": "And "
});
formatter.step({
  "line": 28,
  "name": "I click on change password",
  "keyword": "When "
});
formatter.step({
  "line": 29,
  "name": "I enter the old password and new password and confirm password",
  "keyword": "Then "
});
formatter.step({
  "line": 30,
  "name": "I click on submit",
  "keyword": "And "
});
formatter.examples({
  "line": 32,
  "name": "",
  "description": "",
  "id": "userdashboard-feature;update-the-user-profile;",
  "rows": [
    {
      "cells": [
        "username",
        "password"
      ],
      "line": 33,
      "id": "userdashboard-feature;update-the-user-profile;;1"
    },
    {
      "cells": [
        "lavanya.mutyala1@gmail.com",
        "Lav@12345"
      ],
      "line": 34,
      "id": "userdashboard-feature;update-the-user-profile;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 1385242,
  "status": "passed"
});
formatter.scenario({
  "line": 34,
  "name": "Update the user profile",
  "description": "",
  "id": "userdashboard-feature;update-the-user-profile;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 19,
      "name": "@Userprofile"
    },
    {
      "line": 22,
      "name": "@changePasswordScenario"
    },
    {
      "line": 19,
      "name": "@all"
    }
  ]
});
formatter.step({
  "line": 24,
  "name": "I open the browser and navigate to home page of website",
  "keyword": "Given "
});
formatter.step({
  "line": 25,
  "name": "I click on login  and go to login page",
  "keyword": "When "
});
formatter.step({
  "line": 26,
  "name": "I enter the valid \"lavanya.mutyala1@gmail.com\" and \"Lav@12345\" and click on signin",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 27,
  "name": "I navigate to profile page",
  "keyword": "And "
});
formatter.step({
  "line": 28,
  "name": "I click on change password",
  "keyword": "When "
});
formatter.step({
  "line": 29,
  "name": "I enter the old password and new password and confirm password",
  "keyword": "Then "
});
formatter.step({
  "line": 30,
  "name": "I click on submit",
  "keyword": "And "
});
formatter.match({
  "location": "UserProfileStepDefinition.i_open_the_browser_and_navigate_to_home_page_of_website()"
});
formatter.result({
  "duration": 4069573875,
  "status": "passed"
});
formatter.match({
  "location": "UserProfileStepDefinition.i_click_on_login_and_go_to_login_page()"
});
formatter.result({
  "duration": 12034350600,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "lavanya.mutyala1@gmail.com",
      "offset": 19
    },
    {
      "val": "Lav@12345",
      "offset": 52
    }
  ],
  "location": "UserProfileStepDefinition.i_enter_the_valid_and_and_click_on_signin(String,String)"
});
formatter.result({
  "duration": 34206672,
  "status": "passed"
});
formatter.match({
  "location": "UserProfileStepDefinition.i_navigate_to_profile_page()"
});
formatter.result({
  "duration": 17237877,
  "status": "passed"
});
formatter.match({
  "location": "UserProfileStepDefinition.i_click_on_change_password()"
});
formatter.result({
  "duration": 11652534,
  "status": "passed"
});
formatter.match({
  "location": "UserProfileStepDefinition.i_enter_the_old_password_and_new_password_and_confirm_password()"
});
formatter.result({
  "duration": 12006383,
  "status": "passed"
});
formatter.match({
  "location": "UserProfileStepDefinition.i_click_on_submit()"
});
formatter.result({
  "duration": 704572438,
  "status": "passed"
});
formatter.after({
  "duration": 7495100,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 37,
  "name": "Edit profile and booking history",
  "description": "",
  "id": "userdashboard-feature;edit-profile-and-booking-history",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 36,
      "name": "@Edit_profile_and_booking_history_Scenario"
    }
  ]
});
formatter.step({
  "line": 38,
  "name": "I open the browser and navigate to home page of website",
  "keyword": "Given "
});
formatter.step({
  "line": 39,
  "name": "I click on login button  and go to login page",
  "keyword": "When "
});
formatter.step({
  "line": 40,
  "name": "I enter the valid \"\u003cusername\u003e\" and \"\u003cpassword\u003e\" and click on signin",
  "keyword": "Then "
});
formatter.step({
  "line": 41,
  "name": "I navigate to profile page",
  "keyword": "And "
});
formatter.step({
  "line": 42,
  "name": "I click on edit profile",
  "keyword": "When "
});
formatter.step({
  "line": 43,
  "name": "I see the edit profile page",
  "keyword": "Then "
});
formatter.step({
  "line": 44,
  "name": "I click on booking history",
  "keyword": "When "
});
formatter.step({
  "line": 45,
  "name": "I see the booking history page",
  "keyword": "Then "
});
formatter.examples({
  "line": 47,
  "name": "",
  "description": "",
  "id": "userdashboard-feature;edit-profile-and-booking-history;",
  "rows": [
    {
      "cells": [
        "username",
        "password"
      ],
      "line": 48,
      "id": "userdashboard-feature;edit-profile-and-booking-history;;1"
    },
    {
      "cells": [
        "lavanya.mutyala1@gmail.com",
        "Lav@12345"
      ],
      "line": 49,
      "id": "userdashboard-feature;edit-profile-and-booking-history;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 1405723,
  "status": "passed"
});
formatter.scenario({
  "line": 49,
  "name": "Edit profile and booking history",
  "description": "",
  "id": "userdashboard-feature;edit-profile-and-booking-history;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 19,
      "name": "@Userprofile"
    },
    {
      "line": 36,
      "name": "@Edit_profile_and_booking_history_Scenario"
    },
    {
      "line": 19,
      "name": "@all"
    }
  ]
});
formatter.step({
  "line": 38,
  "name": "I open the browser and navigate to home page of website",
  "keyword": "Given "
});
formatter.step({
  "line": 39,
  "name": "I click on login button  and go to login page",
  "keyword": "When "
});
formatter.step({
  "line": 40,
  "name": "I enter the valid \"lavanya.mutyala1@gmail.com\" and \"Lav@12345\" and click on signin",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 41,
  "name": "I navigate to profile page",
  "keyword": "And "
});
formatter.step({
  "line": 42,
  "name": "I click on edit profile",
  "keyword": "When "
});
formatter.step({
  "line": 43,
  "name": "I see the edit profile page",
  "keyword": "Then "
});
formatter.step({
  "line": 44,
  "name": "I click on booking history",
  "keyword": "When "
});
formatter.step({
  "line": 45,
  "name": "I see the booking history page",
  "keyword": "Then "
});
formatter.match({
  "location": "UserProfileStepDefinition.i_open_the_browser_and_navigate_to_home_page_of_website()"
});
formatter.result({
  "duration": 4202855249,
  "status": "passed"
});
formatter.match({
  "location": "UserProfileStepDefinition.i_click_on_login_button_and_go_to_login_page()"
});
formatter.result({
  "duration": 3646419561,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "lavanya.mutyala1@gmail.com",
      "offset": 19
    },
    {
      "val": "Lav@12345",
      "offset": 52
    }
  ],
  "location": "UserProfileStepDefinition.i_enter_the_valid_and_and_click_on_signin(String,String)"
});
formatter.result({
  "duration": 31570444,
  "status": "passed"
});
formatter.match({
  "location": "UserProfileStepDefinition.i_navigate_to_profile_page()"
});
formatter.result({
  "duration": 12687911,
  "status": "passed"
});
formatter.match({
  "location": "UserProfileStepDefinition.i_click_on_edit_profile()"
});
formatter.result({
  "duration": 16734981,
  "status": "passed"
});
formatter.match({
  "location": "UserProfileStepDefinition.i_see_the_edit_profile_page()"
});
formatter.result({
  "duration": 19911,
  "status": "passed"
});
formatter.match({
  "location": "UserProfileStepDefinition.i_click_on_booking_history()"
});
formatter.result({
  "duration": 33429570,
  "status": "passed"
});
formatter.match({
  "location": "UserProfileStepDefinition.i_see_the_booking_history_page()"
});
formatter.result({
  "duration": 627529632,
  "status": "passed"
});
formatter.after({
  "duration": 4395798,
  "status": "passed"
});
});