package mobiletests;

import org.openqa.selenium.Platform;
import org.openqa.selenium.remote.DesiredCapabilities;
import com.testinium.deviceinformation.DeviceInfo;
import com.testinium.deviceinformation.DeviceInfoImpl;
import com.testinium.deviceinformation.device.DeviceType;
import com.testinium.deviceinformation.exception.DeviceNotFoundException;
import com.testinium.deviceinformation.model.Device;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;

public class DesiredCaps {
	public static DesiredCapabilities setCapabilities() throws Exception, DeviceNotFoundException {
		DesiredCapabilities caps = new DesiredCapabilities();
		DeviceInfo deviceInfo = new DeviceInfoImpl(DeviceType.ANDROID);
		Device device = deviceInfo.getFirstDevice();

		caps.setCapability(MobileCapabilityType.AUTOMATION_NAME, "Appium");
		caps.setCapability(MobileCapabilityType.DEVICE_NAME, device.getModelNumber());
		caps.setCapability(MobileCapabilityType.PLATFORM_NAME, Platform.ANDROID);
		caps.setCapability(MobileCapabilityType.PLATFORM_VERSION, device.getProductVersion());
		caps.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, 120);
		caps.setCapability(AndroidMobileCapabilityType.ANDROID_DEVICE_READY_TIMEOUT, 30);
		caps.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, "com.whatsapp");
		caps.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, "com.whatsapp.HomeActivity");
		caps.setCapability(MobileCapabilityType.NO_RESET, true);
		
		return caps;
	}
}
