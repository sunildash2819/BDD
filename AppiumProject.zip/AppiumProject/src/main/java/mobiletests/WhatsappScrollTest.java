package mobiletests;

import org.testng.annotations.Test;
import com.testinium.deviceinformation.exception.DeviceNotFoundException;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import org.testng.annotations.BeforeTest;
import java.net.URL;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterTest;

public class WhatsappScrollTest {

	AndroidDriver<MobileElement> driver;
	AppiumServer server=new AppiumServer();
	String contactName = "";
	String message = "";

	@BeforeTest
	public void setup() throws DeviceNotFoundException, Exception {
		System.out.println("Starting Server");
		server.startServer();
		
		System.out.println("Starting Mobile Test");
		System.out.println("Setting Capabilities");
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities=DesiredCaps.setCapabilities();

		driver = new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		System.out.println("Driver Launched");
	}

	@Test
	public void sendMessage() {
		contactName = "Ravali";
		message = "Hello";

		MobileElement whatsappOption = driver.findElementByXPath("//*[@text='WhatsApp']");
		whatsappOption.click();

		System.out.println("Selecting Contact");
		MobileElement contactList = driver.findElementById("android:id/list");

		/*
		 * MobileElement targetContact = ((AndroidElement)
		 * contactList).findElementByAndroidUIAutomator(
		 * "new UiScrollable(new UiSelector()).scrollIntoView(new UiSelector().textContains(\""
		 * + contactName + "\"));");
		 */

		MobileElement targetContact = contactList.findElement(MobileBy
				.AndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(new UiSelector().textContains(\""
						+ contactName + "\"));"));
		targetContact.click();
		System.out.println("Contact Selected");

		System.out.println("Sending Message");
		MobileElement messageBox = driver.findElementById("com.whatsapp:id/entry");
		messageBox.sendKeys(message);

		MobileElement sendOption = driver.findElementById("com.whatsapp:id/send");
		// sendOption.click();
		System.out.println("Message Sent");
		driver.pressKey(new KeyEvent(AndroidKey.HOME));
	}

	@AfterTest
	public void teardown() {
		if (driver != null) {
			System.out.println("Closing Android Driver");
			driver.quit();
		}
		server.stopServer();
		System.out.println("Stopping Server");
	}

}
