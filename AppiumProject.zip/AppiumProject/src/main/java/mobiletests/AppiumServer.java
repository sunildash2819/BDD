package mobiletests;

import java.io.File;
import java.util.concurrent.TimeUnit;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;
import io.appium.java_client.service.local.flags.GeneralServerFlag;

public class AppiumServer {

	public String NodeJsPath = "C:\\Program Files\\nodejs\\node.exe";
	public String AppiumMainJsPath = "C:\\Users\\PC-sunil\\AppData\\Local\\Programs\\Appium\\resources\\app\\node_modules\\appium\\build\\lib\\main.js";
	public AppiumDriverLocalService service;

	public void startServer() throws InterruptedException {
		service = AppiumDriverLocalService
				.buildService(new AppiumServiceBuilder().withArgument(GeneralServerFlag.LOG_LEVEL, "error")
						.usingDriverExecutable(new File(NodeJsPath)).withAppiumJS(new File(AppiumMainJsPath))
						.withIPAddress("127.0.0.1").usingPort(4723).withStartUpTimeOut(20, TimeUnit.SECONDS));
		service.start();
	}

	public void stopServer() {
		if (service.isRunning()) {
			service.stop();
		}
	}
}
