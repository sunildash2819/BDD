package mobiletests;
import org.testng.annotations.Test;

import com.testinium.deviceinformation.exception.DeviceNotFoundException;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;
import org.testng.annotations.BeforeTest;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.Platform;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterTest;

public class WhatsAppTest {
	AppiumDriver<MobileElement> driver;
	AppiumServer server=new AppiumServer();
	String contactName = "";
	String message = "";

	@BeforeTest
	public void setup() throws DeviceNotFoundException, Exception {
		System.out.println("Starting Server");
		server.startServer();
		
		System.out.println("Starting Mobile Test");
		System.out.println("Setting Capabilities");
		DesiredCaps caps=new DesiredCaps();
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities=caps.setCapabilities();

		driver = new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		System.out.println("Driver Launched");
	}

	@Test
	public void sendMessage() {
		contactName = "Ranju";
		message = "Hello";
		MobileElement whatsappOption = driver.findElementByXPath("//*[@text='WhatsApp']");
		whatsappOption.click();

		MobileElement searchOption = driver.findElementById("com.whatsapp:id/menuitem_search");
		searchOption.click();
		
		MobileElement searchTextbox = driver.findElementById("com.whatsapp:id/search_src_text");
		System.out.println("Selecting Contact");
		searchTextbox.sendKeys(contactName);
		
		MobileElement contact = driver.findElement(MobileBy.AndroidUIAutomator(
				"new UiSelector().resourceId(\"com.whatsapp:id/conversations_row_contact_name\").instance(0)"));
		contact.click();
		System.out.println("Contact Selected");
		
		System.out.println("Sending Message");
		MobileElement messageBox = driver.findElementById("com.whatsapp:id/entry");
		messageBox.sendKeys(message);
		
		MobileElement sendOption = driver.findElementById("com.whatsapp:id/send");
		sendOption.click();
		System.out.println("Message Sent");
				
	}

	@AfterTest
	public void teardown() {
		if(driver!=null)
		{
			System.out.println("Closing Android Driver");
			driver.quit();
		}
	}

}
