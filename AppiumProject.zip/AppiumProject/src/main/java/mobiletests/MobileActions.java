package mobiletests;

import java.net.URL;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.testinium.deviceinformation.exception.DeviceNotFoundException;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.MultiTouchAction;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidTouchAction;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.functions.ExpectedCondition;
import io.appium.java_client.touch.LongPressOptions;
import io.appium.java_client.touch.TapOptions;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.ElementOption;
import io.appium.java_client.touch.offset.PointOption;

public class MobileActions {

	AndroidDriver<MobileElement> driver;
	AppiumServer server;
	String contactName="";
	
	@BeforeTest
	public void setup() throws DeviceNotFoundException, Exception {
		System.out.println("Starting Server");
		server=new AppiumServer();
		server.startServer();
		
		System.out.println("Starting Mobile Test");
		System.out.println("Setting Capabilities");
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities=DesiredCaps.setCapabilities();

		driver = new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		System.out.println("Driver Launched");
	}
	
	@Test(enabled=false)
	public void tapAction() throws Exception
	{
		contactName="Anwesha";
		AndroidTouchAction action =new AndroidTouchAction(driver);
		MobileElement whatsappOption = driver.findElementByXPath("//*[@text='WhatsApp']");
		action.tap(TapOptions.tapOptions().withElement(ElementOption.element(whatsappOption))).perform();
		
		System.out.println("Selecting Contact");
		MobileElement contactList = driver.findElementById("android:id/list");
		
		MobileElement targetContact = contactList.findElement(MobileBy
				.AndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(new UiSelector().textContains(\""
						+ contactName + "\"));"));
		Thread.sleep(2000);
		action.tap(TapOptions.tapOptions().withElement(ElementOption.element(targetContact))).perform();
		Thread.sleep(5000);
	}
	
	@Test(enabled=false)
	public void longPressAction() throws Exception
	{
		contactName="Anwesha";
		AndroidTouchAction action =new AndroidTouchAction(driver);
		MobileElement whatsappOption = driver.findElementByXPath("//*[@text='WhatsApp']");
		action.tap(TapOptions.tapOptions().withElement(ElementOption.element(whatsappOption))).perform();
		
		System.out.println("Selecting Contact");
		MobileElement contactList = driver.findElementById("android:id/list");
		
		MobileElement targetContact = contactList.findElement(MobileBy
				.AndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(new UiSelector().textContains(\""
						+ contactName + "\"));"));
		action.longPress(LongPressOptions.longPressOptions().withElement(ElementOption.element(targetContact))
				.withDuration(Duration.ofSeconds(3))).release().perform();
		System.out.println("contact long pressed");
		
		MobileElement moreOptions=driver.findElementByXPath("//*[@content-desc='More options']");
		moreOptions.click();
		System.out.println("Image view selected");
		
		List<MobileElement> moreOptionsList=driver.findElementsById("com.whatsapp:id/title");
		for(MobileElement option:moreOptionsList)
		{
			String optionName=option.getText();
			if(optionName.equalsIgnoreCase("View contact"))
			{
				option.click();
				break;
			}
		}
		Thread.sleep(2000);
		System.out.println("View contact selected");
		
		MobileElement conversationContactName=driver.findElementById("com.whatsapp:id/conversation_contact_name");
		Assert.assertTrue(conversationContactName.getText().contains(contactName),
				"Contact selected doesn't match with contact name");
		Thread.sleep(3000);
		driver.pressKey(new KeyEvent(AndroidKey.HOME));		
		Thread.sleep(2000);
	}
	
	@Test(enabled=true)
	public void zoomAction() throws Exception
	{
		AndroidTouchAction action =new AndroidTouchAction(driver);
		MobileElement whatsappOption = driver.findElementByXPath("//*[@text='WhatsApp']");
		action.tap(TapOptions.tapOptions().withElement(ElementOption.element(whatsappOption))).perform();
		
		MobileElement contactImage=driver.findElementsById("com.whatsapp:id/contact_photo").get(0);
		action.tap(TapOptions.tapOptions().withElement(ElementOption.element(contactImage))).perform();		
		Thread.sleep(2000);
		System.out.println("contact image selected");
		
		MobileElement picture=driver.findElementById("com.whatsapp:id/picture");
		picture.click();
		System.out.println("picture clicked");
		
		MobileElement picAnimation=driver.findElementById("com.whatsapp:id/picture_animation");
		System.out.println(picAnimation.getTagName());
		System.out.println(picAnimation.getCoordinates());
		System.out.println(picAnimation.getCenter());
		System.out.println(picAnimation.getLocation());
		System.out.println(picAnimation.getSize());
		
		PointOption<?> startPoint1 = PointOption.point(picAnimation.getCenter().getX(),
				picAnimation.getCenter().getY());
		PointOption<?> endPoint1 = PointOption.point(picAnimation.getCenter().getX() - 300,
				picAnimation.getCenter().getY() - 100);
		PointOption<?> startPoint2 = PointOption.point(picAnimation.getCenter().getX(),
				picAnimation.getCenter().getY());
		PointOption<?> endPoint2 = PointOption.point(picAnimation.getCenter().getX() + 300,
				picAnimation.getCenter().getY() + 100);
	    
		TouchAction<?> action1 =new AndroidTouchAction(driver);
		action1.press(startPoint1).waitAction(WaitOptions.waitOptions(Duration.ofSeconds(3))).moveTo(endPoint1)
				.release().perform();
		
		TouchAction<?> action2 = new AndroidTouchAction(driver);
		action2.press(startPoint2).waitAction(WaitOptions.waitOptions(Duration.ofSeconds(3))).moveTo(endPoint2)
				.release().perform();

		MultiTouchAction multiTouch=new MultiTouchAction(driver);
		multiTouch.add(action1).add(action2).perform();
		try {
		Alert alert=waitForAlert(driver, 30);
		System.out.println(alert.getText());
		alert.accept();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		Thread.sleep(10000);
		multiTouch.add(action1).add(action2).perform();
		System.out.println("contact image zoomed");
		Thread.sleep(2000);
		
		driver.pressKey(new KeyEvent(AndroidKey.HOME));	
	}
	public static Alert waitForAlert(WebDriver driver,long waitTime)
	{
		WebDriverWait wait=new WebDriverWait(driver, waitTime);
		return wait.until(new ExpectedCondition<Alert>() {
			@Override
			public Alert apply(WebDriver driver) {
				// TODO Auto-generated method stub
				return driver.switchTo().alert();
			}		
		});
	}
	
	@AfterTest
	public void teardown() {
		if (driver != null) {
			System.out.println("Closing Android Driver");
			driver.quit();
		}
		server.stopServer();
		System.out.println("Stopping Server");
	}
}
