package jiraapis;

import static io.restassured.RestAssured.given;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class JiraTest {

	public static void main(String[] args) {
		RestAssured.baseURI="http://localhost:8080/";
	}
	
	public static String getSessionKEY()
	{
		RestAssured.baseURI= "http://localhost:8080";
		String res=given().header("Content-Type", "application/json").
		body("{ \"username\": \"rahulonlinetutor\", \"password\": \"Jira12345\" }").
		when().
		post("/rest/auth/1/session").then().statusCode(200).
		extract().response().asString();
		 JsonPath js= new JsonPath(res);
		String sessionid= js.get("session.value");
		return sessionid;
	}

}
