package demo;

import org.testng.annotations.Test;
import files.Payload;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import static io.restassured.RestAssured.*;

public class LibraryAPI {

	@Test
	public void runAPI() {
		RestAssured.baseURI = "http://216.10.245.166";
		
		//ADD
		String response = given().header("Content-Type", "application/json")
				.body(Payload.addLibrary("sunil", "123"))
				.when().post("/Library/Addbook.php")
				.then().log().all().assertThat().statusCode(200)
				.extract().response().asString();
		JsonPath js = new JsonPath(response);
		String id = js.get("ID");
		System.out.println("ID : "+id);
		
		//DELETE
		given().header("Content-Type", "application/json").body(Payload.deleteLibrary(id))
		.when().post("/Library/DeleteBook.php")
		.then().log().all().assertThat().statusCode(200);
	}

}
