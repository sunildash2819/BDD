package demo;

import files.Payload;
import io.restassured.path.json.JsonPath;

public class ParseJson {

	public static void main(String[] args) {
		JsonPath js = new JsonPath(Payload.coursePriceResponse());
		int count = js.getInt("courses.size()");
		System.out.println("No of courses : "+count);
		
		int purchaseAmount = js.get("dashboard.purchaseAmount");
		System.out.println("Purchase Amount : "+purchaseAmount);
		
		/*String firstCourseTitle = js.get("courses[0].title");
		System.out.println("Title of the first course : "+firstCourseTitle);
		
		for(int i=0;i<count;i++) {
			System.out.println("Course : "+js.get("courses["+i+"].title"));
			System.out.println("Price : "+js.get("courses["+i+"].price"));
		}*/
		
		/*for(int i=0;i<count;i++) {
			String title=js.get("courses["+i+"].title");
			if(title.equals("RPA")) {
				System.out.println("Course : "+js.get("courses["+i+"].title"));
				System.out.println("Copies : "+js.get("courses["+i+"].copies"));
				break;
			}
		}*/
		
		int totalPrice=0;
		for(int i=0;i<count;i++) {
			totalPrice+=js.getInt("courses["+i+"].price") * js.getInt("courses["+i+"].copies");
		}
		System.out.println("Total price : "+totalPrice);
		
		if(totalPrice==purchaseAmount) 
			System.out.println("Total price is same as purchase amount ");
		else
			System.out.println("Total price is not same as purchase amount ");
	}

}
