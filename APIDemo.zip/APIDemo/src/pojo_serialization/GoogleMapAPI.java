package pojo_serialization;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.filter.log.LogDetail;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

import static io.restassured.RestAssured.*;

import java.util.ArrayList;

public class GoogleMapAPI {

	public static void main(String[] args) {
//		RestAssured.baseURI = "https://rahulshettyacademy.com/";
		AddPlacePayload addPlace = addPlaceValues();
		
		RequestSpecification reqSpec = new RequestSpecBuilder().setBaseUri("https://rahulshettyacademy.com/")
				.setContentType(ContentType.JSON).addQueryParam("key", "qaclick123").log(LogDetail.ALL).build();
		
		ResponseSpecification resSpec = new ResponseSpecBuilder().expectStatusCode(200)
				.expectContentType(ContentType.JSON).log(LogDetail.ALL).build();

		RequestSpecification req = given().spec(reqSpec).body(addPlace);
		String response = req.when().post("/maps/api/place/add/json")
				.then().spec(resSpec)
				.extract().response().asString();
	}
	
	public static AddPlacePayload addPlaceValues() {
		AddPlacePayload addPlace = new AddPlacePayload();
		Location location = new Location();
		
		location.setLat(34.234);
		location.setLng(65.345);
		
		addPlace.setAccuracy(50);
		addPlace.setAddress("Greensboro, USA");
		addPlace.setLanguage("EN-US");
		addPlace.setLocation(location);
		addPlace.setName("Frontline house");
		addPlace.setPhoneNumber("9438211545");
		addPlace.setWebsite("https://rahulshetty.com");
		
		ArrayList<String> types = new ArrayList<>();
		types.add("shoe park");
		types.add("shop");
		addPlace.setTypes(types);
		
		return addPlace;
	}

}
